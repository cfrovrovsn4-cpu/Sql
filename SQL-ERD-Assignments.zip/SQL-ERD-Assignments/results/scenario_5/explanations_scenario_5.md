# Scenario 5 — Required explanations (one filtered query, one JOIN query)

Snapshot date: 2026-11-07. Raw operational data is audited; the qualifying-sale filter is not used.

## Filtered query — Task 5.2 (overdue pending shipments)
Order 215 (Pending, ShipDate NULL, OrderDate 2026-10-30) is included because it is 8 days old on 2026-11-07, i.e. `OrderDate < 2026-10-31`. Order 224 (Pending, OrderDate 2026-11-02) is excluded because it is only 5 days old, and an order dated exactly 2026-10-31 would also be excluded because it is exactly seven days old, not more than seven.

## JOIN query — Task 5.7 (pending workload per Sales employee)
Nina Stone (ID 15) appears with PendingOrderCount 0 and PendingSales 0 because the query starts from all Sales employees and uses a `LEFT JOIN` whose `ON` clause holds the Pending/NULL-ShipDate conditions. If those conditions were in `WHERE`, her NULL-filled row would be removed and the workload report would silently miss her.

## Notes on results
- 5.5 (inconsistent records) returns exactly two audit rows, left unchanged: order 221 (Shipped but ShipDate NULL) and order 222 (ShipDate 2026-10-30 earlier than OrderDate 2026-10-31).
- 5.4 returns only order 206 (ship address New York, billing address Boston); this is a review item, not necessarily an error.
- 5.6 returns only order 202 (10 days to ship). Order 222 is not in it because its ShipDate is before OrderDate, and Pending/Cancelled orders have no ShipDate.
- No Scenario 5 query returned an empty result.

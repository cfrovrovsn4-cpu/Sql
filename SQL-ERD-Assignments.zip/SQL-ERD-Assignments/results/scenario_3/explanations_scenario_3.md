# Scenario 3 — Notes

- 3.8, 3.9 and 3.10 ran only on `SalesDB_Practice.sqlite` (ProductID 501 does not exist in the reference data; StockQuantity exists only in the practice copy). The empty result before 3.8 confirms 501 was unused.
- 3.5 returns Desk Lamp (108): no order refers to it.
- 3.6 uses an INNER JOIN as the task says, so Alex Green (13), who has no orders, is not listed. Only Maya Brown (10,250) exceeds 5,000 in 3.7.
- 3.4: ProductID 101 and 105 tie at quantity 7; the tie is broken by ProductID ascending.
- 3.11 lists name combinations only (UNION removes identical first/last name pairs); it does not prove two rows are the same person.

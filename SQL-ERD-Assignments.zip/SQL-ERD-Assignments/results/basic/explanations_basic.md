# Basic tasks — Notes

- B01–B09 ran on the clean reference copy; B10 ran only on the practice copy (ProductID 900 inserted, price updated 10 -> 15, verified, deleted; 8 products remain).
- B10 explanation: `UPDATE`/`DELETE` without `WHERE` affect every row of the table. `WHERE ProductID = 900` targets the one intended row because ProductID is the primary key.
- B05 uses BETWEEN, which is inclusive of 50 and 300.

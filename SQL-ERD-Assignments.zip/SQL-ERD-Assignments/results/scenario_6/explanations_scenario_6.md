# Scenario 6 — Required explanations (one filtered query, one JOIN query)

Qualifying sales only (Shipped/Delivered, ShipDate not NULL and >= OrderDate). October = 2026-10-01..31, November snapshot = 2026-11-01..07, assigned by OrderDate.

## Filtered query — Task 6.4 (staff meeting the monthly target)
David Lee (ID 11) is included because his five qualifying October orders (201, 206, 211, 213, 223) total 1,855, which satisfies `COUNT >= 2 AND SUM >= 1000` in `HAVING`. Nina Stone (ID 15) is excluded because she has no qualifying October order, and the Pending/non-qualifying orders of other staff (for example 212 and 215) were removed by the status/date rules before grouping.

## JOIN query — Task 6.2 (October scorecard)
Nina Stone appears with 0 orders, 0 quantity and 0 sales because the scorecard starts from all Sales employees and `LEFT JOIN`s the qualifying October orders; `COALESCE` turns the NULL sums into 0. An `INNER JOIN` would have removed her.

## Notes on results
- 6.3: Maya Brown's team (direct Sales reports 11, 14, 15) has 3 staff, 8 orders and 4,385 sales; Maya's own 8,070 is deliberately not included, and Alex Green (Support) is not counted as Sales staff.
- 6.7 returns customers 1, 2, 3 (qualifying sales in both periods); 6.8 returns 5, 6, 8 (**no return by 2026-11-07**, not permanent inactivity); 6.9 returns 7 (**new to the comparison period**; not proven first-time because earlier history is not in the data).
- 6.10 contains 11 October rows and 4 November rows; UNION ALL keeps all rows and the periods cannot overlap.
- No Scenario 6 query returned an empty result.

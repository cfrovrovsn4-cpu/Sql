# Scenario 2 — Notes

- OrderIDs 105, 110 and 999 do not exist in the reference data, so Tasks 2.5–2.7 first create valid temporary rows (valid ProductID/CustomerID/SalesPersonID) **only in `SalesDB_Practice.sqlite`**; each task previews the row with SELECT before UPDATE/DELETE and verifies afterwards. Order 105 and 110 remain in the practice copy; 999 is deleted.
- The empty results shown before each INSERT are the expected "does this ID exist yet?" checks, not errors.
- Tasks 2.8 and 2.9 were run on the clean reference copy so the temporary practice rows do not change the counts. Reference counts: Delivered 11, Pending 6, Shipped 6, Cancelled 1.
- Task 2.3 returns only order 202 (10 days). Pending orders have ShipDate NULL, and NULL minus a date is NULL, so they are not "> 7".
- Task 2.9 keeps OrderStatus so that Pending work (203, 208, 212, 215, 218, 224), the Cancelled order (210) and the inconsistent Shipped order (221) can be told apart.

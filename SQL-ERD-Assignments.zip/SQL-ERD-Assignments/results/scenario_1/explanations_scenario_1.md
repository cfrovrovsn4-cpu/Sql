# Scenario 1 — Required explanation

**Customer with no orders vs. customer whose orders fail a campaign filter**

A customer with *no orders* has no matching row in `Orders` at all (Task 1.4 returns CustomerID 9, Ali Hasanov). A customer whose orders merely *fail a filter* (for example "Sales > 1,000" in Task 1.6, or a status/date rule in a campaign) does have orders, so they are an active customer who just does not meet that campaign's condition. Example: Sara Martin (ID 4) has two orders (208, 222) but her total of 340 is below the 1,000 threshold, so she is absent from Task 1.6 yet is not "inactive".

Technically the two cases need different SQL: "no orders" is found with `LEFT JOIN ... WHERE o.OrderID IS NULL`, while "fails a filter" is expressed with `WHERE` / `HAVING` on rows that exist. Using `INNER JOIN` (Tasks 1.3, 1.5) would silently drop customers without orders.

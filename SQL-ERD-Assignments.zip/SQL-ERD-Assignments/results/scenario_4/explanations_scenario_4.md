# Scenario 4 — Required explanations (one filtered query, one JOIN query)

Qualifying October sale = Shipped/Delivered, ShipDate not NULL, ShipDate >= OrderDate, OrderDate in 2026-10-01..2026-10-31.

## Filtered query — Task 4.2 (priority electronics orders)
Order 206 (John Miller, USA, Smart Phone) is included although his Score is 450, because the second alternative (`Sales >= 1000`, here 1260) is true and the order also passes the Electronics, USA and qualifying-October conditions. Order 213 (USB Hub, Sales 135, same customer) is excluded because neither alternative holds (Score 450 < 500 and Sales 135 < 1000); order 210 (Laptop, Sales 1700) is excluded too because it is Cancelled, which shows that the parentheses make the status/country/category rules apply to both alternatives.

## JOIN query — Task 4.1 (campaign sales register)
Order 211 (Lukas Weber, Germany, Notebook) is included because it joins to exactly one customer, product and employee through the ID keys and passes the qualifying-October and target-country filters, so it appears once. Order 214 (Sofia Rossi) is excluded because Italy is not a target country, order 221 because its ShipDate is NULL, and order 222 because its ShipDate (2026-10-30) is earlier than its OrderDate (2026-10-31).

## Notes on results
- 4.7 returns Sara Martin (4) and Lea Fischer (7): Sara only has a Pending order and an inconsistent order, Lea only a November order, so both remain eligible for reactivation (LEFT JOIN keeps them).
- 4.8 (INTERSECT) returns only customer 2: John Miller bought Electronics (206, 213) and Furniture (223). 4.9 (UNION) returns 2, 3, 5, 6 and 4.10 (EXCEPT) returns 3 and 5.
- No Scenario 4 query returned an empty result.

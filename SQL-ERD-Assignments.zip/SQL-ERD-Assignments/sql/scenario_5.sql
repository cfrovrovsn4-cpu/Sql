-- ============================================================================
-- SCENARIO 5 — Fulfilment exception desk (tasks 5.1–5.10)
-- All read-only -> run on SalesDB.sqlite (clean reference copy)
--
-- Snapshot date: 2026-11-07. Only orders with OrderDate <= '2026-11-07' are
-- considered. This scenario audits RAW operational data, so the qualifying-sale
-- filter of Scenarios 4 and 6 is NOT used (unless a task asks for a valid
-- shipment date). Records 221 and 222 are inconsistent on purpose and are never
-- repaired.
-- Date arithmetic in SQLite: julianday(a) - julianday(b) = days between a and b.
-- ============================================================================

-- [TASK 5.1] Pending work queue
-- Every Pending order up to the snapshot date, oldest first; one row per order.
SELECT o.OrderID,
       o.OrderDate,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       o.Quantity,
       o.Sales,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       o.ShipAddress
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.OrderDate <= '2026-11-07'
ORDER BY o.OrderDate, o.OrderID;

-- [TASK 5.2] Overdue pending shipments
-- "More than 7 days old" on 2026-11-07 means OrderDate < 2026-10-31
-- (2026-10-31 is exactly 7 days old). date('2026-11-07','-7 days') = '2026-10-31'.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       p.Product,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       o.Sales
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate < date('2026-11-07', '-7 days')
ORDER BY o.OrderDate, o.OrderID;

-- [TASK 5.3] Missing delivery addresses
-- NULL and '' are different values, so both are tested (TRIM also catches '  ').
SELECT o.OrderID,
       c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       o.ShipAddress
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.OrderDate <= '2026-11-07'
  AND (o.ShipAddress IS NULL OR TRIM(o.ShipAddress) = '')
ORDER BY o.OrderID;

-- [TASK 5.4] Different billing addresses
-- Both addresses must be present and non-empty before they are compared
-- (a comparison with NULL is never true). A difference is only for review.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.ShipAddress,
       o.BillAddress,
       o.OrderStatus
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipAddress IS NOT NULL AND TRIM(o.ShipAddress) <> ''
  AND o.BillAddress IS NOT NULL AND TRIM(o.BillAddress) <> ''
  AND o.ShipAddress <> o.BillAddress
ORDER BY o.OrderID;

-- [TASK 5.5] Inconsistent shipment records (audit only — nothing is altered)
-- Alternative 1: ShipDate earlier than OrderDate.
-- Alternative 2: status Shipped/Delivered but ShipDate missing.
-- Parentheses make the status condition belong to alternative 2 only.
SELECT o.OrderID,
       o.OrderStatus,
       o.OrderDate,
       o.ShipDate,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderDate <= '2026-11-07'
  AND ( o.ShipDate < o.OrderDate
        OR ( o.OrderStatus IN ('Shipped', 'Delivered') AND o.ShipDate IS NULL ) )
ORDER BY o.OrderID;

-- [TASK 5.6] Late dispatch investigation
-- Non-cancelled orders with a valid ShipDate (>= OrderDate) shipped more than 7 days later.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       p.Product,
       o.OrderDate,
       o.ShipDate,
       CAST(julianday(o.ShipDate) - julianday(o.OrderDate) AS INTEGER) AS DaysToShip
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY DaysToShip DESC, o.OrderID;

-- [TASK 5.7] Pending workload per Sales employee
-- Start from ALL Sales employees (LEFT JOIN). The Pending/NULL-ShipDate test is
-- placed in the ON clause: in WHERE it would delete employees with no such
-- orders. COUNT(o.OrderID) counts only real matches; COALESCE turns NULL sums into 0.
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(o.OrderID)           AS PendingOrderCount,
       COALESCE(SUM(o.Sales), 0)  AS PendingSales
FROM Employees AS e
LEFT JOIN Orders AS o
       ON  o.SalesPersonID = e.EmployeeID
       AND o.OrderStatus   = 'Pending'
       AND o.ShipDate IS NULL
       AND o.OrderDate    <= '2026-11-07'
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
ORDER BY e.EmployeeID;

-- [TASK 5.8] Customers needing one combined follow-up
-- Group by CustomerID; HAVING keeps customers with 2 or more such orders.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       COUNT(o.OrderID) AS PendingOrderCount,
       SUM(o.Sales)     AS PendingSales
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate <= '2026-11-07'
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(o.OrderID) >= 2
ORDER BY PendingSales DESC, c.CustomerID;

-- [TASK 5.9] Priority support list
-- Country, amount and "not cancelled" apply to BOTH alternatives (outer AND).
-- Alternative A: Pending with no ShipDate.
-- Alternative B: valid ShipDate (>= OrderDate) with a dispatch delay > 7 days.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       o.Sales,
       o.OrderStatus,
       o.OrderDate,
       o.ShipDate
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND c.Country IN ('Germany', 'USA')
  AND o.Sales >= 500
  AND (
        (o.OrderStatus = 'Pending' AND o.ShipDate IS NULL)
        OR
        (o.ShipDate IS NOT NULL
         AND o.ShipDate >= o.OrderDate
         AND julianday(o.ShipDate) - julianday(o.OrderDate) > 7)
      )
ORDER BY o.OrderID;

-- [TASK 5.10] Ready-to-dispatch checklist
-- Pending, no ShipDate, and a usable (non-NULL, non-empty) ShipAddress.
-- BillAddress is deliberately NOT required.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       o.Quantity,
       o.ShipAddress,
       e.FirstName || ' ' || e.LastName AS EmployeeName
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipAddress IS NOT NULL
  AND TRIM(o.ShipAddress) <> ''
ORDER BY c.Country, o.OrderDate, o.OrderID;

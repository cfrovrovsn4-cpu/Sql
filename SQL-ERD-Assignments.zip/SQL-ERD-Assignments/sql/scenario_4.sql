-- ============================================================================
-- SCENARIO 4 — Targeted campaign planning (tasks 4.1–4.10)
-- All read-only -> run on SalesDB.sqlite (clean reference copy)
--
-- QUALIFYING OCTOBER SALE (CTE "qs", repeated in each query so every task
-- can be run on its own):
--   * OrderStatus is 'Shipped' or 'Delivered'
--   * ShipDate IS NOT NULL
--   * ShipDate >= OrderDate
--   * OrderDate between 2026-10-01 and 2026-10-31 (inclusive)
-- Target countries: Germany, France, USA.
-- Task 4.3 searches the product catalogue and has no order-period filter.
-- ============================================================================

-- [TASK 4.1] Campaign sales register
-- One row per qualifying October order (4 inner joins on ID keys, no row multiplication).
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT qs.OrderID,
       qs.OrderDate,
       c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       p.Category,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       qs.Quantity,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID  = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID   = qs.ProductID
INNER JOIN Employees AS e ON e.EmployeeID  = qs.SalesPersonID
WHERE c.Country IN ('Germany', 'France', 'USA')
ORDER BY c.Country, qs.OrderDate, qs.OrderID;

-- [TASK 4.2] Priority electronics orders
-- The OR is wrapped in parentheses so the category/country/period conditions
-- apply to BOTH alternatives (Score >= 500 OR Sales >= 1000).
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT qs.OrderID,
       c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       c.Score,
       p.Product,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND p.Category = 'Electronics'
  AND (c.Score >= 500 OR qs.Sales >= 1000)
ORDER BY qs.OrderID;

-- [TASK 4.3] Affordable products to promote (catalogue search, no order filter)
-- Parentheses group the two LIKE alternatives (Wireless OR USB).
SELECT ProductID, Product, Category, Price
FROM Products
WHERE Category = 'Electronics'
  AND Price BETWEEN 40 AND 100
  AND (Product LIKE '%Wireless%' OR Product LIKE '%USB%')
ORDER BY Price, ProductID;

-- [TASK 4.4] Unique recipient list
-- DISTINCT: a customer with several matching orders appears once.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT DISTINCT c.CustomerID, c.FirstName, c.LastName, c.Country, c.Score
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND c.Score >= 500
  AND p.Category = 'Electronics'
ORDER BY c.CustomerID;

-- [TASK 4.5] High-value accounts
-- WHERE (before grouping) = status/date/country rules.
-- HAVING (after grouping)  = at least 2 orders AND total Sales >= 1000.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       COUNT(qs.OrderID)  AS OrderCount,
       SUM(qs.Quantity)   AS TotalQuantity,
       SUM(qs.Sales)      AS TotalSales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
WHERE c.Country IN ('Germany', 'France', 'USA')
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(qs.OrderID) >= 2
   AND SUM(qs.Sales) >= 1000
ORDER BY TotalSales DESC, c.CustomerID;

-- [TASK 4.6] Country-category demand
-- Groups by Country + Category; only groups with total Sales > 500 remain.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.Country,
       p.Category,
       COUNT(qs.OrderID) AS OrderCount,
       SUM(qs.Quantity)  AS TotalQuantity,
       SUM(qs.Sales)     AS TotalSales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
GROUP BY c.Country, p.Category
HAVING SUM(qs.Sales) > 500
ORDER BY TotalSales DESC, c.Country, p.Category;

-- [TASK 4.7] Customers without eligible activity
-- LEFT JOIN from ALL target-country customers to the qualifying orders.
-- Customers whose only orders are Pending/Cancelled/inconsistent/November have
-- no match in qs, so q.OrderID IS NULL keeps them on the reactivation list.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       c.Score
FROM Customers AS c
LEFT JOIN qs AS q ON q.CustomerID = c.CustomerID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND q.OrderID IS NULL
ORDER BY c.CustomerID;

-- [TASK 4.8] Cross-category buyers (INTERSECT)
-- Set 1: Electronics buyers. Set 2: Furniture buyers. INTERSECT = in both sets.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Electronics'
INTERSECT
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Furniture'
ORDER BY CustomerID;

-- [TASK 4.9] Combined audiences (UNION)
-- UNION removes duplicates, so a customer who bought both categories appears once.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Electronics'
UNION
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Furniture'
ORDER BY CustomerID;

-- [TASK 4.10] Furniture cross-sell list (EXCEPT)
-- Electronics buyers MINUS Furniture buyers = Electronics-only customers.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Electronics'
EXCEPT
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Furniture'
ORDER BY CustomerID;

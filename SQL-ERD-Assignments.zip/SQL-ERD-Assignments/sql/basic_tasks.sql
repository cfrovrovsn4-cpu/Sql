-- ============================================================================
-- BASIC SQL TASKS B01–B10          DBMS: SQLite (DB Browser for SQLite)
-- B01–B09 are read-only  -> run on SalesDB.sqlite (reference copy)
-- B10 changes data       -> run ONLY on SalesDB_Practice.sqlite (practice copy)
-- ============================================================================

-- [TASK B01] Explore a table (SELECT / FROM)
-- First all columns, then only three selected columns.
SELECT * FROM Customers;

SELECT FirstName, LastName, Country
FROM Customers;

-- [TASK B02] Filter by country (WHERE / =)
-- Customers from Germany only.
SELECT CustomerID, FirstName, LastName, Country
FROM Customers
WHERE Country = 'Germany';

-- [TASK B03] Combine conditions (WHERE / AND / IN)
-- Score at least 300 AND country is Germany or France.
SELECT CustomerID, FirstName, LastName, Country, Score
FROM Customers
WHERE Score >= 300
  AND Country IN ('Germany', 'France');

-- [TASK B04] Sort products (ORDER BY / DESC)
-- Most expensive first.
SELECT ProductID, Product, Category, Price
FROM Products
ORDER BY Price DESC;

-- [TASK B05] Search within a range (BETWEEN)
-- BETWEEN is inclusive: prices of exactly 50 and 300 would be included.
SELECT Product, Price
FROM Products
WHERE Price BETWEEN 50 AND 300;

-- [TASK B06] Search text patterns (LIKE)
-- % matches any text before/after the word "Phone".
SELECT Product, Category
FROM Products
WHERE Product LIKE '%Phone%';

-- [TASK B07] Find distinct values (DISTINCT / ORDER BY)
-- Each category once, alphabetical.
SELECT DISTINCT Category
FROM Products
ORDER BY Category ASC;

-- [TASK B08] Connect customer orders (INNER JOIN)
-- Each order with the first and last name of its customer (key: CustomerID).
SELECT o.OrderID, c.FirstName, c.LastName
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
ORDER BY o.OrderID;

-- [TASK B09] Summarize orders (COUNT / SUM / GROUP BY)
-- Number of orders and total stored Sales per status, highest total first.
-- Sales is already the order total, so it is NOT multiplied by Quantity.
SELECT OrderStatus,
       COUNT(OrderID) AS OrderCount,
       SUM(Sales)     AS TotalSales
FROM Orders
GROUP BY OrderStatus
ORDER BY TotalSales DESC;

-- [TASK B10 | PRACTICE] Safe data change (INSERT / UPDATE / DELETE / WHERE)
-- Run on the PRACTICE copy only. Product ID 900 is unused in the reference data.

-- (a) Make sure 900 is really unused
SELECT * FROM Products WHERE ProductID = 900;

-- (b) INSERT the temporary product
INSERT INTO Products (ProductID, Product, Category, Price)
VALUES (900, 'Temporary Test Product', 'Electronics', 10.00);

-- (c) UPDATE only its price (WHERE targets exactly ProductID 900)
UPDATE Products
SET Price = 15.00
WHERE ProductID = 900;

-- (d) VERIFY the change
SELECT * FROM Products WHERE ProductID = 900;

-- (e) DELETE only that product
DELETE FROM Products
WHERE ProductID = 900;

-- (f) VERIFY it is gone and the other products are untouched (expect 8 rows)
SELECT COUNT(*) AS ProductsLeft FROM Products;
SELECT * FROM Products WHERE ProductID = 900;

-- WHY WHERE MATTERS: UPDATE/DELETE without WHERE affect EVERY row in the table.
-- "UPDATE Products SET Price = 15.00;" would give all products the price 15,
-- and "DELETE FROM Products;" would empty the table. WHERE ProductID = 900
-- restricts the change to the single intended row (ProductID is the primary key).

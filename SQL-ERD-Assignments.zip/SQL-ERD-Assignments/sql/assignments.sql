-- ============================================================================
-- SQL & RELATIONAL DATABASE DESIGN — SalesDB — COMPLETE SUBMISSION FILE
-- DBMS used: SQLite 3 (DB Browser for SQLite)
--
-- PART 1  Database setup (CREATE TABLE + 46 reference rows)
-- PART 2  Read-only tasks, in numeric order (run on the clean reference data):
--         B01–B09, 1.1–1.7, 2.1–2.4, 2.8–2.9, 3.1–3.7, 3.11–3.12,
--         4.1–4.10, 5.1–5.10, 6.1–6.10
-- PART 3  Modification exercises (B10, 2.5–2.7, 3.8–3.10). These change data
--         (INSERT/UPDATE/DELETE/ALTER). They are wrapped in a SAVEPOINT that is
--         rolled back at the end, so this file never leaves changes in the
--         reference database. The permanent practice copy is
--         database/SalesDB_Practice.sqlite (same statements, committed).
-- Task numbers match the assignment. Separate topic files are in sql/.
-- ============================================================================

-- ############################################################################
-- PART 1 — DATABASE SETUP
-- ############################################################################
-- ============================================================================
-- SalesDB — DATABASE SETUP (reference dataset)
-- DBMS: SQLite 3 (DB Browser for SQLite)
-- Contents: CREATE TABLE statements + all 46 reference rows
--           (9 Customers, 8 Products, 5 Employees, 24 Orders)
--
-- NOTE: This script DROPs and recreates the four tables, so running it again
--       restores the clean reference dataset at any time.
-- ============================================================================

PRAGMA foreign_keys = ON;   -- SQLite does not enforce foreign keys unless this is ON

-- Drop in child-to-parent order so foreign keys never block the DROP
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Employees;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Customers;

-- ----------------------------------------------------------------------------
-- Table 1: Customers
-- ----------------------------------------------------------------------------
CREATE TABLE Customers (
    CustomerID  INTEGER PRIMARY KEY,
    FirstName   VARCHAR(50),
    LastName    VARCHAR(50),
    Country     VARCHAR(50),
    Score       INTEGER
);

-- ----------------------------------------------------------------------------
-- Table 2: Products
-- ----------------------------------------------------------------------------
CREATE TABLE Products (
    ProductID   INTEGER PRIMARY KEY,
    Product     VARCHAR(100),
    Category    VARCHAR(50),
    Price       DECIMAL(10,2)
);

-- ----------------------------------------------------------------------------
-- Table 3: Employees (ManagerID is a nullable self-reference)
-- ----------------------------------------------------------------------------
CREATE TABLE Employees (
    EmployeeID  INTEGER PRIMARY KEY,
    FirstName   VARCHAR(50),
    LastName    VARCHAR(50),
    Department  VARCHAR(50),
    BirthDate   DATE,
    Gender      VARCHAR(10),
    Salary      DECIMAL(10,2),
    ManagerID   INTEGER,
    FOREIGN KEY (ManagerID) REFERENCES Employees (EmployeeID)
);

-- ----------------------------------------------------------------------------
-- Table 4: Orders (one record = one order = one product)
-- No CHECK constraint on ShipDate: the two audit records (221, 222) must load.
-- ----------------------------------------------------------------------------
CREATE TABLE Orders (
    OrderID        INTEGER PRIMARY KEY,
    ProductID      INTEGER,
    CustomerID     INTEGER,
    SalesPersonID  INTEGER,
    OrderDate      DATE,
    ShipDate       DATE,
    OrderStatus    VARCHAR(30),
    ShipAddress    VARCHAR(150),
    BillAddress    VARCHAR(150),
    Quantity       INTEGER,
    Sales          DECIMAL(10,2),
    CreationTime   DATETIME,
    FOREIGN KEY (ProductID)     REFERENCES Products  (ProductID),
    FOREIGN KEY (CustomerID)    REFERENCES Customers (CustomerID),
    FOREIGN KEY (SalesPersonID) REFERENCES Employees (EmployeeID)
);

-- ============================================================================
-- REFERENCE DATA
-- ============================================================================

-- Customers (9 rows)
INSERT INTO Customers (CustomerID, FirstName, LastName, Country, Score) VALUES
(1, 'Ayla',  'Karimova', 'Azerbaijan', 720),
(2, 'John',  'Miller',   'USA',        450),
(3, 'Emma',  'Schmidt',  'Germany',    860),
(4, 'Sara',  'Martin',   'France',     280),
(5, 'Lukas', 'Weber',    'Germany',    550),
(6, 'Noah',  'Adams',    'USA',        610),
(7, 'Lea',   'Fischer',  'Germany',    680),
(8, 'Sofia', 'Rossi',    'Italy',      700),
(9, 'Ali',   'Hasanov',  'Azerbaijan', 330);

-- Products (8 rows)
INSERT INTO Products (ProductID, Product, Category, Price) VALUES
(101, 'Wireless Mouse', 'Electronics', 55.00),
(102, 'Office Chair',   'Furniture',   230.00),
(103, 'Laptop',         'Electronics', 850.00),
(104, 'Notebook',       'Stationery',  12.00),
(105, 'Smart Phone',    'Electronics', 420.00),
(106, 'Standing Desk',  'Furniture',   380.00),
(107, 'USB Hub',        'Electronics', 45.00),
(108, 'Desk Lamp',      'Furniture',   65.00);

-- Employees (5 rows) — manager 12 is inserted first because the others refer to her
INSERT INTO Employees (EmployeeID, FirstName, LastName, Department, BirthDate, Gender, Salary, ManagerID) VALUES
(12, 'Maya',  'Brown', 'Sales',   '1990-07-09', 'Female', 2400.00, NULL);
INSERT INTO Employees (EmployeeID, FirstName, LastName, Department, BirthDate, Gender, Salary, ManagerID) VALUES
(11, 'David', 'Lee',   'Sales',   '1987-05-14', 'Male',   2200.00, 12),
(13, 'Alex',  'Green', 'Support', '1994-11-21', 'Male',   1900.00, 12),
(14, 'Omar',  'Ali',   'Sales',   '1995-02-17', 'Male',   2100.00, 12),
(15, 'Nina',  'Stone', 'Sales',   '1998-08-03', 'Female', 2000.00, 12);

-- Orders (24 rows = 4 original + 20 additional, merged with the shipping details)
-- CreationTime = OrderDate + ' 10:00:00'.  Sales is the TOTAL for the order
-- (never multiply it by Quantity).  NULL below is a real SQL NULL.
INSERT INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime) VALUES
(201, 101, 1, 11, '2026-10-04', '2026-10-06', 'Delivered', '10 Nizami St, Baku',     '10 Nizami St, Baku',     2,   110, '2026-10-04 10:00:00'),
(202, 103, 3, 12, '2026-10-08', '2026-10-18', 'Shipped',   '22 Oak St, Berlin',      '22 Oak St, Berlin',      1,   850, '2026-10-08 10:00:00'),
(203, 102, 2, 11, '2026-10-12', NULL,         'Pending',   NULL,                     '45 Main St, New York',   1,   230, '2026-10-12 10:00:00'),
(204, 105, 5, 12, '2026-10-15', '2026-10-19', 'Delivered', '16 Park Rd, Munich',     '16 Park Rd, Munich',     1,   420, '2026-10-15 10:00:00'),
(205, 103, 3, 12, '2026-10-20', '2026-10-22', 'Delivered', '22 Oak St, Berlin',      '22 Oak St, Berlin',      8,  6800, '2026-10-20 10:00:00'),
(206, 105, 2, 11, '2026-10-21', '2026-10-23', 'Delivered', '45 Main St, New York',   '9 Pine St, Boston',      3,  1260, '2026-10-21 10:00:00'),
(207, 102, 6, 14, '2026-10-22', '2026-10-24', 'Delivered', '31 Oak St, Boston',      '31 Oak St, Boston',      4,   920, '2026-10-22 10:00:00'),
(208, 101, 4, 11, '2026-10-23', NULL,         'Pending',   NULL,                     '8 Rue Lyon, Paris',      2,   110, '2026-10-23 10:00:00'),
(209, 106, 1, 14, '2026-10-24', '2026-10-27', 'Delivered', '10 Nizami St, Baku',     '10 Nizami St, Baku',     2,   760, '2026-10-24 10:00:00'),
(210, 103, 6, 14, '2026-10-25', NULL,         'Cancelled', '31 Oak St, Boston',      '31 Oak St, Boston',      2,  1700, '2026-10-25 10:00:00'),
(211, 104, 5, 11, '2026-10-26', '2026-10-28', 'Delivered', '16 Park Rd, Munich',     '16 Park Rd, Munich',    10,   120, '2026-10-26 10:00:00'),
(212, 105, 3, 12, '2026-10-27', NULL,         'Pending',   NULL,                     '22 Oak St, Berlin',      2,   840, '2026-10-27 10:00:00'),
(213, 107, 2, 11, '2026-10-28', '2026-10-30', 'Shipped',   '45 Main St, New York',   '45 Main St, New York',   3,   135, '2026-10-28 10:00:00'),
(214, 103, 8, 14, '2026-10-29', '2026-11-01', 'Delivered', '18 Via Roma, Milan',     '18 Via Roma, Milan',     1,   850, '2026-10-29 10:00:00'),
(215, 106, 5, 12, '2026-10-30', NULL,         'Pending',   '16 Park Rd, Munich',     '16 Park Rd, Munich',     1,   380, '2026-10-30 10:00:00'),
(216, 101, 1, 11, '2026-11-02', '2026-11-04', 'Delivered', '10 Nizami St, Baku',     '10 Nizami St, Baku',     1,    55, '2026-11-02 10:00:00'),
(217, 102, 7, 14, '2026-11-03', '2026-11-05', 'Shipped',   '9 River St, Berlin',     '9 River St, Berlin',     1,   230, '2026-11-03 10:00:00'),
(218, 105, 6, 14, '2026-11-04', NULL,         'Pending',   '31 Oak St, Boston',      NULL,                     1,   420, '2026-11-04 10:00:00'),
(219, 103, 3, 12, '2026-11-05', '2026-11-06', 'Shipped',   '22 Oak St, Berlin',      '22 Oak St, Berlin',      1,   850, '2026-11-05 10:00:00'),
(220, 104, 2, 11, '2026-11-06', '2026-11-07', 'Delivered', '45 Main St, New York',   '45 Main St, New York',   5,    60, '2026-11-06 10:00:00'),
(221, 107, 6, 14, '2026-10-28', NULL,         'Shipped',   '31 Oak St, Boston',      '31 Oak St, Boston',      1,    45, '2026-10-28 10:00:00'),
(222, 102, 4, 11, '2026-10-31', '2026-10-30', 'Shipped',   '8 Rue Lyon, Paris',      '8 Rue Lyon, Paris',      1,   230, '2026-10-31 10:00:00'),
(223, 102, 2, 11, '2026-10-29', '2026-10-31', 'Delivered', '45 Main St, New York',   '45 Main St, New York',   1,   230, '2026-10-29 10:00:00'),
(224, 101, 3, 12, '2026-11-02', NULL,         'Pending',   '22 Oak St, Berlin',      '22 Oak St, Berlin',      2,   110, '2026-11-02 10:00:00');

-- ############################################################################
-- PART 2 — READ-ONLY TASKS (reference data)
-- ############################################################################

-- [TASK B01] Explore a table (SELECT / FROM)
-- First all columns, then only three selected columns.
SELECT * FROM Customers;

SELECT FirstName, LastName, Country
FROM Customers;

-- [TASK B02] Filter by country (WHERE / =)
-- Customers from Germany only.
SELECT CustomerID, FirstName, LastName, Country
FROM Customers
WHERE Country = 'Germany';

-- [TASK B03] Combine conditions (WHERE / AND / IN)
-- Score at least 300 AND country is Germany or France.
SELECT CustomerID, FirstName, LastName, Country, Score
FROM Customers
WHERE Score >= 300
  AND Country IN ('Germany', 'France');

-- [TASK B04] Sort products (ORDER BY / DESC)
-- Most expensive first.
SELECT ProductID, Product, Category, Price
FROM Products
ORDER BY Price DESC;

-- [TASK B05] Search within a range (BETWEEN)
-- BETWEEN is inclusive: prices of exactly 50 and 300 would be included.
SELECT Product, Price
FROM Products
WHERE Price BETWEEN 50 AND 300;

-- [TASK B06] Search text patterns (LIKE)
-- % matches any text before/after the word "Phone".
SELECT Product, Category
FROM Products
WHERE Product LIKE '%Phone%';

-- [TASK B07] Find distinct values (DISTINCT / ORDER BY)
-- Each category once, alphabetical.
SELECT DISTINCT Category
FROM Products
ORDER BY Category ASC;

-- [TASK B08] Connect customer orders (INNER JOIN)
-- Each order with the first and last name of its customer (key: CustomerID).
SELECT o.OrderID, c.FirstName, c.LastName
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
ORDER BY o.OrderID;

-- [TASK B09] Summarize orders (COUNT / SUM / GROUP BY)
-- Number of orders and total stored Sales per status, highest total first.
-- Sales is already the order total, so it is NOT multiplied by Quantity.
SELECT OrderStatus,
       COUNT(OrderID) AS OrderCount,
       SUM(Sales)     AS TotalSales
FROM Orders
GROUP BY OrderStatus
ORDER BY TotalSales DESC;

-- [TASK 1.1] High-score customers
-- Score strictly greater than 500, highest score first.
SELECT FirstName, LastName, Country, Score
FROM Customers
WHERE Score > 500
ORDER BY Score DESC;

-- [TASK 1.2] Target countries
-- IN() is a short form of several OR conditions; Score >= 300 is inclusive.
SELECT FirstName, LastName, Country, Score
FROM Customers
WHERE Country IN ('Germany', 'France', 'USA')
  AND Score >= 300
ORDER BY CustomerID;

-- [TASK 1.3] Purchase history
-- INNER JOIN on CustomerID: only orders that have a matching customer.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       o.Sales
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
ORDER BY o.OrderID;

-- [TASK 1.4] Inactive customers
-- LEFT JOIN keeps every customer; customers with no order get NULL in o.OrderID.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country
FROM Customers AS c
LEFT JOIN Orders AS o ON o.CustomerID = c.CustomerID
WHERE o.OrderID IS NULL
ORDER BY c.CustomerID;

-- [TASK 1.5] Total customer spending
-- Grouped by CustomerID (not by name) so two customers with the same name stay separate.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName, c.Country
ORDER BY TotalSales DESC, c.CustomerID;

-- [TASK 1.6] Loyalty threshold
-- HAVING filters AFTER grouping (WHERE cannot filter on SUM()).
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName, c.Country
HAVING SUM(o.Sales) > 1000
ORDER BY TotalSales DESC, c.CustomerID;

-- [TASK 1.7] Top-five report
-- Same totals, limited to five rows. Ties are broken by CustomerID ascending.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName, c.Country
ORDER BY TotalSales DESC, c.CustomerID
LIMIT 5;

-- [TASK 2.1] October orders
-- Both boundary dates are included (BETWEEN is inclusive).
SELECT OrderID, CustomerID, OrderDate, ShipDate, OrderStatus
FROM Orders
WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
ORDER BY OrderDate, OrderID;

-- [TASK 2.2] Pending queue
-- Oldest order first.
SELECT OrderID, CustomerID, OrderDate, ShipDate, OrderStatus
FROM Orders
WHERE OrderStatus = 'Pending'
ORDER BY OrderDate ASC, OrderID ASC;

-- [TASK 2.3] Late shipments
-- SQLite has no DATEDIFF: julianday() converts a date to a day number, so the
-- difference is the number of days. NULL ShipDate gives NULL, so it is not > 7.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       o.ShipDate
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY o.OrderID;

-- [TASK 2.4] Affected customers
-- DISTINCT so a customer with several delayed orders is listed once.
SELECT DISTINCT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY c.CustomerID;

-- ---------------------------------------------------------------------------
-- 2.5–2.7: PRACTICE COPY ONLY. OrderIDs 105, 110 and 999 do not exist in the
-- reference data, so valid temporary rows are created first (valid ProductID,
-- CustomerID and SalesPersonID, otherwise the foreign keys would reject them).
-- ---------------------------------------------------------------------------

-- [TASK 2.8] Status distribution (reference copy)
SELECT OrderStatus, COUNT(OrderID) AS OrderCount
FROM Orders
GROUP BY OrderStatus
ORDER BY OrderCount DESC, OrderStatus;

-- [TASK 2.9] Unshipped records (reference copy)
-- IS NULL (not "= NULL") tests for missing values. OrderStatus is kept so
-- Pending work, Cancelled orders and inconsistent rows (e.g. Shipped but no
-- ShipDate) can be told apart.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       o.ShipDate,
       o.OrderStatus
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE o.ShipDate IS NULL
ORDER BY o.OrderDate, o.OrderID;

-- [TASK 3.1] Affordable products
SELECT Product, Category, Price
FROM Products
WHERE Price BETWEEN 50 AND 300
ORDER BY Price ASC;

-- [TASK 3.2] Premium electronics
SELECT ProductID, Product, Category, Price
FROM Products
WHERE Category = 'Electronics'
  AND Price > 500;

-- [TASK 3.3] Product sales
-- One row per order, joined to its product through ProductID.
SELECT p.Product, p.Category, o.Quantity, o.Sales
FROM Products AS p
INNER JOIN Orders AS o ON o.ProductID = p.ProductID
ORDER BY o.OrderID;

-- [TASK 3.4] Best-selling products (top five by total Quantity)
-- Grouped by ProductID; ties are broken by ProductID ascending.
SELECT p.ProductID, p.Product, SUM(o.Quantity) AS TotalQuantity
FROM Products AS p
INNER JOIN Orders AS o ON o.ProductID = p.ProductID
GROUP BY p.ProductID, p.Product
ORDER BY TotalQuantity DESC, p.ProductID
LIMIT 5;

-- [TASK 3.5] Unsold items
-- LEFT JOIN keeps all products; no matching order -> o.OrderID IS NULL.
SELECT p.ProductID, p.Product, p.Category, p.Price
FROM Products AS p
LEFT JOIN Orders AS o ON o.ProductID = p.ProductID
WHERE o.OrderID IS NULL
ORDER BY p.ProductID;

-- [TASK 3.6] Employee performance
-- Employees.EmployeeID = Orders.SalesPersonID. INNER JOIN, so an employee with
-- no orders (EmployeeID 13) does not appear.
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department,
       SUM(o.Sales) AS TotalSales
FROM Employees AS e
INNER JOIN Orders AS o ON o.SalesPersonID = e.EmployeeID
GROUP BY e.EmployeeID, e.FirstName, e.LastName, e.Department
ORDER BY TotalSales DESC, e.EmployeeID;

-- [TASK 3.7] Top-performing staff (total Sales above 5,000)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department,
       SUM(o.Sales) AS TotalSales
FROM Employees AS e
INNER JOIN Orders AS o ON o.SalesPersonID = e.EmployeeID
GROUP BY e.EmployeeID, e.FirstName, e.LastName, e.Department
HAVING SUM(o.Sales) > 5000
ORDER BY TotalSales DESC;

-- ---------------------------------------------------------------------------
-- 3.8–3.10: PRACTICE COPY ONLY (ProductID 501 is intentionally absent from
-- the reference data).
-- ---------------------------------------------------------------------------

-- [TASK 3.11] Combined directory
-- UNION removes duplicate (FirstName, LastName) pairs. It lists name
-- combinations only; it does not prove two rows are the same person.
SELECT FirstName, LastName FROM Customers
UNION
SELECT FirstName, LastName FROM Employees
ORDER BY LastName, FirstName;

-- [TASK 3.12] Category performance
-- HAVING keeps only categories whose grouped total exceeds 2,000.
SELECT p.Category,
       SUM(o.Quantity) AS TotalQuantity,
       SUM(o.Sales)    AS TotalSales
FROM Products AS p
INNER JOIN Orders AS o ON o.ProductID = p.ProductID
GROUP BY p.Category
HAVING SUM(o.Sales) > 2000
ORDER BY TotalSales DESC;

-- [TASK 4.1] Campaign sales register
-- One row per qualifying October order (4 inner joins on ID keys, no row multiplication).
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT qs.OrderID,
       qs.OrderDate,
       c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       p.Category,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       qs.Quantity,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID  = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID   = qs.ProductID
INNER JOIN Employees AS e ON e.EmployeeID  = qs.SalesPersonID
WHERE c.Country IN ('Germany', 'France', 'USA')
ORDER BY c.Country, qs.OrderDate, qs.OrderID;

-- [TASK 4.2] Priority electronics orders
-- The OR is wrapped in parentheses so the category/country/period conditions
-- apply to BOTH alternatives (Score >= 500 OR Sales >= 1000).
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT qs.OrderID,
       c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       c.Score,
       p.Product,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND p.Category = 'Electronics'
  AND (c.Score >= 500 OR qs.Sales >= 1000)
ORDER BY qs.OrderID;

-- [TASK 4.3] Affordable products to promote (catalogue search, no order filter)
-- Parentheses group the two LIKE alternatives (Wireless OR USB).
SELECT ProductID, Product, Category, Price
FROM Products
WHERE Category = 'Electronics'
  AND Price BETWEEN 40 AND 100
  AND (Product LIKE '%Wireless%' OR Product LIKE '%USB%')
ORDER BY Price, ProductID;

-- [TASK 4.4] Unique recipient list
-- DISTINCT: a customer with several matching orders appears once.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT DISTINCT c.CustomerID, c.FirstName, c.LastName, c.Country, c.Score
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND c.Score >= 500
  AND p.Category = 'Electronics'
ORDER BY c.CustomerID;

-- [TASK 4.5] High-value accounts
-- WHERE (before grouping) = status/date/country rules.
-- HAVING (after grouping)  = at least 2 orders AND total Sales >= 1000.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       COUNT(qs.OrderID)  AS OrderCount,
       SUM(qs.Quantity)   AS TotalQuantity,
       SUM(qs.Sales)      AS TotalSales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
WHERE c.Country IN ('Germany', 'France', 'USA')
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(qs.OrderID) >= 2
   AND SUM(qs.Sales) >= 1000
ORDER BY TotalSales DESC, c.CustomerID;

-- [TASK 4.6] Country-category demand
-- Groups by Country + Category; only groups with total Sales > 500 remain.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.Country,
       p.Category,
       COUNT(qs.OrderID) AS OrderCount,
       SUM(qs.Quantity)  AS TotalQuantity,
       SUM(qs.Sales)     AS TotalSales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
GROUP BY c.Country, p.Category
HAVING SUM(qs.Sales) > 500
ORDER BY TotalSales DESC, c.Country, p.Category;

-- [TASK 4.7] Customers without eligible activity
-- LEFT JOIN from ALL target-country customers to the qualifying orders.
-- Customers whose only orders are Pending/Cancelled/inconsistent/November have
-- no match in qs, so q.OrderID IS NULL keeps them on the reactivation list.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       c.Score
FROM Customers AS c
LEFT JOIN qs AS q ON q.CustomerID = c.CustomerID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND q.OrderID IS NULL
ORDER BY c.CustomerID;

-- [TASK 4.8] Cross-category buyers (INTERSECT)
-- Set 1: Electronics buyers. Set 2: Furniture buyers. INTERSECT = in both sets.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Electronics'
INTERSECT
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Furniture'
ORDER BY CustomerID;

-- [TASK 4.9] Combined audiences (UNION)
-- UNION removes duplicates, so a customer who bought both categories appears once.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Electronics'
UNION
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Furniture'
ORDER BY CustomerID;

-- [TASK 4.10] Furniture cross-sell list (EXCEPT)
-- Electronics buyers MINUS Furniture buyers = Electronics-only customers.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Electronics'
EXCEPT
SELECT c.CustomerID AS CustomerID
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = qs.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA') AND p.Category = 'Furniture'
ORDER BY CustomerID;

-- [TASK 5.1] Pending work queue
-- Every Pending order up to the snapshot date, oldest first; one row per order.
SELECT o.OrderID,
       o.OrderDate,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       o.Quantity,
       o.Sales,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       o.ShipAddress
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.OrderDate <= '2026-11-07'
ORDER BY o.OrderDate, o.OrderID;

-- [TASK 5.2] Overdue pending shipments
-- "More than 7 days old" on 2026-11-07 means OrderDate < 2026-10-31
-- (2026-10-31 is exactly 7 days old). date('2026-11-07','-7 days') = '2026-10-31'.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       p.Product,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       o.Sales
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate < date('2026-11-07', '-7 days')
ORDER BY o.OrderDate, o.OrderID;

-- [TASK 5.3] Missing delivery addresses
-- NULL and '' are different values, so both are tested (TRIM also catches '  ').
SELECT o.OrderID,
       c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       o.ShipAddress
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.OrderDate <= '2026-11-07'
  AND (o.ShipAddress IS NULL OR TRIM(o.ShipAddress) = '')
ORDER BY o.OrderID;

-- [TASK 5.4] Different billing addresses
-- Both addresses must be present and non-empty before they are compared
-- (a comparison with NULL is never true). A difference is only for review.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.ShipAddress,
       o.BillAddress,
       o.OrderStatus
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipAddress IS NOT NULL AND TRIM(o.ShipAddress) <> ''
  AND o.BillAddress IS NOT NULL AND TRIM(o.BillAddress) <> ''
  AND o.ShipAddress <> o.BillAddress
ORDER BY o.OrderID;

-- [TASK 5.5] Inconsistent shipment records (audit only — nothing is altered)
-- Alternative 1: ShipDate earlier than OrderDate.
-- Alternative 2: status Shipped/Delivered but ShipDate missing.
-- Parentheses make the status condition belong to alternative 2 only.
SELECT o.OrderID,
       o.OrderStatus,
       o.OrderDate,
       o.ShipDate,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderDate <= '2026-11-07'
  AND ( o.ShipDate < o.OrderDate
        OR ( o.OrderStatus IN ('Shipped', 'Delivered') AND o.ShipDate IS NULL ) )
ORDER BY o.OrderID;

-- [TASK 5.6] Late dispatch investigation
-- Non-cancelled orders with a valid ShipDate (>= OrderDate) shipped more than 7 days later.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       p.Product,
       o.OrderDate,
       o.ShipDate,
       CAST(julianday(o.ShipDate) - julianday(o.OrderDate) AS INTEGER) AS DaysToShip
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY DaysToShip DESC, o.OrderID;

-- [TASK 5.7] Pending workload per Sales employee
-- Start from ALL Sales employees (LEFT JOIN). The Pending/NULL-ShipDate test is
-- placed in the ON clause: in WHERE it would delete employees with no such
-- orders. COUNT(o.OrderID) counts only real matches; COALESCE turns NULL sums into 0.
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(o.OrderID)           AS PendingOrderCount,
       COALESCE(SUM(o.Sales), 0)  AS PendingSales
FROM Employees AS e
LEFT JOIN Orders AS o
       ON  o.SalesPersonID = e.EmployeeID
       AND o.OrderStatus   = 'Pending'
       AND o.ShipDate IS NULL
       AND o.OrderDate    <= '2026-11-07'
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
ORDER BY e.EmployeeID;

-- [TASK 5.8] Customers needing one combined follow-up
-- Group by CustomerID; HAVING keeps customers with 2 or more such orders.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       COUNT(o.OrderID) AS PendingOrderCount,
       SUM(o.Sales)     AS PendingSales
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate <= '2026-11-07'
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(o.OrderID) >= 2
ORDER BY PendingSales DESC, c.CustomerID;

-- [TASK 5.9] Priority support list
-- Country, amount and "not cancelled" apply to BOTH alternatives (outer AND).
-- Alternative A: Pending with no ShipDate.
-- Alternative B: valid ShipDate (>= OrderDate) with a dispatch delay > 7 days.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       o.Sales,
       o.OrderStatus,
       o.OrderDate,
       o.ShipDate
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND c.Country IN ('Germany', 'USA')
  AND o.Sales >= 500
  AND (
        (o.OrderStatus = 'Pending' AND o.ShipDate IS NULL)
        OR
        (o.ShipDate IS NOT NULL
         AND o.ShipDate >= o.OrderDate
         AND julianday(o.ShipDate) - julianday(o.OrderDate) > 7)
      )
ORDER BY o.OrderID;

-- [TASK 5.10] Ready-to-dispatch checklist
-- Pending, no ShipDate, and a usable (non-NULL, non-empty) ShipAddress.
-- BillAddress is deliberately NOT required.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       p.Product,
       o.Quantity,
       o.ShipAddress,
       e.FirstName || ' ' || e.LastName AS EmployeeName
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN Products  AS p ON p.ProductID  = o.ProductID
INNER JOIN Employees AS e ON e.EmployeeID = o.SalesPersonID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipAddress IS NOT NULL
  AND TRIM(o.ShipAddress) <> ''
ORDER BY c.Country, o.OrderDate, o.OrderID;

-- [TASK 6.1] Reporting lines (self join)
-- Employees is joined to itself: e = the employee, m = the manager.
-- LEFT JOIN keeps Maya Brown (ManagerID IS NULL).
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department,
       e.ManagerID,
       m.FirstName || ' ' || m.LastName AS ManagerName
FROM Employees AS e
LEFT JOIN Employees AS m ON m.EmployeeID = e.ManagerID
ORDER BY e.EmployeeID;

-- [TASK 6.2] October scorecard (all Sales employees, zeros kept)
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(qs.OrderID)           AS OrderCount,
       COALESCE(SUM(qs.Quantity), 0) AS TotalQuantity,
       COALESCE(SUM(qs.Sales), 0)    AS TotalSales
FROM Employees AS e
LEFT JOIN qs ON qs.SalesPersonID = e.EmployeeID
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
ORDER BY TotalSales DESC, e.EmployeeID;

-- [TASK 6.3] Direct-report team summary
-- m = manager, e = DIRECT reports in Sales (e.ManagerID = m.EmployeeID).
-- Orders are joined only for e, so the manager's own sales and indirect reports
-- are excluded. COUNT(DISTINCT e.EmployeeID) counts each employee once even
-- though joining orders repeats the employee on several rows.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT m.EmployeeID AS ManagerID,
       m.FirstName || ' ' || m.LastName AS ManagerName,
       COUNT(DISTINCT e.EmployeeID)   AS DirectSalesStaffCount,
       COUNT(qs.OrderID)              AS TeamOrderCount,
       COALESCE(SUM(qs.Sales), 0)     AS TeamSales
FROM Employees AS m
INNER JOIN Employees AS e
        ON  e.ManagerID  = m.EmployeeID
        AND e.Department = 'Sales'
LEFT JOIN qs ON qs.SalesPersonID = e.EmployeeID
GROUP BY m.EmployeeID, m.FirstName, m.LastName
ORDER BY m.EmployeeID;

-- [TASK 6.4] Staff meeting the monthly target
-- WHERE/ON = row rules (status, dates) BEFORE grouping.
-- HAVING   = target rules (>= 2 orders AND >= 1000) AFTER grouping.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(qs.OrderID) AS OrderCount,
       SUM(qs.Sales)     AS TotalSales
FROM Employees AS e
INNER JOIN qs ON qs.SalesPersonID = e.EmployeeID
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
HAVING COUNT(qs.OrderID) >= 2
   AND SUM(qs.Sales) >= 1000
ORDER BY TotalSales DESC, e.EmployeeID;

-- [TASK 6.5] Customer and country coverage
-- COUNT(DISTINCT ...) so repeat orders for the same customer/country add nothing.
-- LEFT JOINs keep employees with no activity (their distinct counts are 0).
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(DISTINCT qs.CustomerID) AS DistinctCustomers,
       COUNT(DISTINCT c.Country)     AS DistinctCountries
FROM Employees AS e
LEFT JOIN qs        ON qs.SalesPersonID = e.EmployeeID
LEFT JOIN Customers AS c ON c.CustomerID = qs.CustomerID
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
ORDER BY e.EmployeeID;

-- [TASK 6.6] Staff without qualifying October sales
-- LEFT JOIN + "qs.OrderID IS NULL" finds Sales employees with no matching row.
-- Someone who has only non-qualifying orders still appears here.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department
FROM Employees AS e
LEFT JOIN qs ON qs.SalesPersonID = e.EmployeeID
WHERE e.Department = 'Sales'
  AND qs.OrderID IS NULL
ORDER BY e.EmployeeID;

-- [TASK 6.7] Returning customers (INTERSECT)
-- Customers with a qualifying sale in October AND in the November snapshot.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
INTERSECT
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
ORDER BY CustomerID;

-- [TASK 6.8] Customers with no return by 2026-11-07 (EXCEPT)
-- October customers MINUS November-snapshot customers. This means "no
-- qualifying return by 2026-11-07", not permanent inactivity.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
EXCEPT
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
ORDER BY CustomerID;

-- [TASK 6.9] Customers new to the comparison period (reverse EXCEPT)
-- November-snapshot customers with no qualifying October sale. This does NOT
-- prove they are first-time buyers: older history is not in this database.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
EXCEPT
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
ORDER BY CustomerID;

-- [TASK 6.10] Two-period sales register (UNION ALL)
-- UNION ALL keeps every row (no duplicate removal). The date ranges do not
-- overlap, so each order lands in exactly one part.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT 'October 2026' AS PeriodLabel,
       qs.OrderID, qs.OrderDate, c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = qs.SalesPersonID
WHERE qs.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
UNION ALL
SELECT 'November 01–07' AS PeriodLabel,
       qs.OrderID, qs.OrderDate, c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = qs.SalesPersonID
WHERE qs.OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
ORDER BY OrderDate, OrderID;

-- ############################################################################
-- PART 3 — MODIFICATION EXERCISES (practice only; rolled back at the end)
-- ############################################################################
SAVEPOINT practice_exercises;

-- [TASK B10 | PRACTICE] Safe data change (INSERT / UPDATE / DELETE / WHERE)
-- Run on the PRACTICE copy only. Product ID 900 is unused in the reference data.

-- (a) Make sure 900 is really unused
SELECT * FROM Products WHERE ProductID = 900;

-- (b) INSERT the temporary product
INSERT INTO Products (ProductID, Product, Category, Price)
VALUES (900, 'Temporary Test Product', 'Electronics', 10.00);

-- (c) UPDATE only its price (WHERE targets exactly ProductID 900)
UPDATE Products
SET Price = 15.00
WHERE ProductID = 900;

-- (d) VERIFY the change
SELECT * FROM Products WHERE ProductID = 900;

-- (e) DELETE only that product
DELETE FROM Products
WHERE ProductID = 900;

-- (f) VERIFY it is gone and the other products are untouched (expect 8 rows)
SELECT COUNT(*) AS ProductsLeft FROM Products;
SELECT * FROM Products WHERE ProductID = 900;

-- WHY WHERE MATTERS: UPDATE/DELETE without WHERE affect EVERY row in the table.
-- "UPDATE Products SET Price = 15.00;" would give all products the price 15,
-- and "DELETE FROM Products;" would empty the table. WHERE ProductID = 900
-- restricts the change to the single intended row (ProductID is the primary key).

-- [TASK 2.5 | PRACTICE] Status correction for OrderID 105
-- Step 1: does it exist?
SELECT * FROM Orders WHERE OrderID = 105;
-- Step 2: create the temporary record if missing (OR IGNORE = do nothing if it exists)
INSERT OR IGNORE INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime)
VALUES (105, 101, 1, 11, '2026-11-01', NULL, 'Pending', '10 Nizami St, Baku', '10 Nizami St, Baku', 1, 55, '2026-11-01 10:00:00');
-- Step 3: preview the row that will change
SELECT OrderID, OrderStatus, ShipDate FROM Orders WHERE OrderID = 105;
-- Step 4: update ONLY OrderID 105
UPDATE Orders
SET OrderStatus = 'Shipped',
    ShipDate    = '2026-11-05'
WHERE OrderID = 105;
-- Step 5: verify
SELECT OrderID, OrderStatus, ShipDate FROM Orders WHERE OrderID = 105;

-- [TASK 2.6 | PRACTICE] Address correction for OrderID 110
SELECT * FROM Orders WHERE OrderID = 110;
INSERT OR IGNORE INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime)
VALUES (110, 102, 2, 11, '2026-11-01', NULL, 'Pending', '45 Main St, New York', '45 Main St, New York', 1, 230, '2026-11-01 10:00:00');
SELECT OrderID, ShipAddress FROM Orders WHERE OrderID = 110;  -- before
UPDATE Orders
SET ShipAddress = '45 Main Street, Baku'
WHERE OrderID = 110;
SELECT OrderID, ShipAddress FROM Orders WHERE OrderID = 110;  -- after

-- [TASK 2.7 | PRACTICE] Remove test data (OrderID 999)
SELECT * FROM Orders WHERE OrderID = 999;
INSERT OR IGNORE INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime)
VALUES (999, 104, 9, 15, '2026-11-01', NULL, 'Pending', 'TEST ADDRESS', 'TEST ADDRESS', 1, 12, '2026-11-01 10:00:00');
SELECT * FROM Orders WHERE OrderID = 999;                      -- preview: exactly one row
DELETE FROM Orders
WHERE OrderID = 999;                                           -- only this row
SELECT COUNT(*) AS Row999AfterDelete FROM Orders WHERE OrderID = 999;  -- expect 0

-- [TASK 3.8 | PRACTICE] New product
SELECT * FROM Products WHERE ProductID = 501;    -- expect no row
INSERT INTO Products (ProductID, Product, Category, Price)
VALUES (501, 'Wireless Keyboard', 'Electronics', 75);
SELECT * FROM Products WHERE ProductID = 501;    -- verify

-- [TASK 3.9 | PRACTICE] Price correction
SELECT ProductID, Price FROM Products WHERE ProductID = 501;  -- before: 75
UPDATE Products
SET Price = 90
WHERE ProductID = 501;
SELECT ProductID, Price FROM Products WHERE ProductID = 501;  -- after: 90

-- [TASK 3.10 | PRACTICE] Inventory column
-- ALTER TABLE ... ADD COLUMN is supported by SQLite. Existing rows get NULL.
ALTER TABLE Products ADD COLUMN StockQuantity INTEGER;
SELECT ProductID, Product, Price, StockQuantity FROM Products ORDER BY ProductID;

-- Undo everything from PART 3 so the reference data stays clean
ROLLBACK TO practice_exercises;
RELEASE practice_exercises;

-- Final check: reference data must be unchanged (expect 9, 8, 5, 24)
SELECT (SELECT COUNT(*) FROM Customers) AS Customers,
       (SELECT COUNT(*) FROM Products)  AS Products,
       (SELECT COUNT(*) FROM Employees) AS Employees,
       (SELECT COUNT(*) FROM Orders)    AS Orders;

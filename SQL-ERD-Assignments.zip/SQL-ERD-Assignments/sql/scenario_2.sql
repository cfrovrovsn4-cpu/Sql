-- ============================================================================
-- SCENARIO 2 — Order and delivery investigation (tasks 2.1–2.9)
-- 2.1–2.4, 2.8, 2.9 are read-only -> run on SalesDB.sqlite (reference copy)
-- 2.5–2.7 change data             -> run ONLY on SalesDB_Practice.sqlite
-- (2.8 and 2.9 are run on the reference copy so the counts are not
--  affected by the temporary practice rows 105 and 110.)
-- ============================================================================

-- [TASK 2.1] October orders
-- Both boundary dates are included (BETWEEN is inclusive).
SELECT OrderID, CustomerID, OrderDate, ShipDate, OrderStatus
FROM Orders
WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
ORDER BY OrderDate, OrderID;

-- [TASK 2.2] Pending queue
-- Oldest order first.
SELECT OrderID, CustomerID, OrderDate, ShipDate, OrderStatus
FROM Orders
WHERE OrderStatus = 'Pending'
ORDER BY OrderDate ASC, OrderID ASC;

-- [TASK 2.3] Late shipments
-- SQLite has no DATEDIFF: julianday() converts a date to a day number, so the
-- difference is the number of days. NULL ShipDate gives NULL, so it is not > 7.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       o.ShipDate
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY o.OrderID;

-- [TASK 2.4] Affected customers
-- DISTINCT so a customer with several delayed orders is listed once.
SELECT DISTINCT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY c.CustomerID;

-- ---------------------------------------------------------------------------
-- 2.5–2.7: PRACTICE COPY ONLY. OrderIDs 105, 110 and 999 do not exist in the
-- reference data, so valid temporary rows are created first (valid ProductID,
-- CustomerID and SalesPersonID, otherwise the foreign keys would reject them).
-- ---------------------------------------------------------------------------

-- [TASK 2.5 | PRACTICE] Status correction for OrderID 105
-- Step 1: does it exist?
SELECT * FROM Orders WHERE OrderID = 105;
-- Step 2: create the temporary record if missing (OR IGNORE = do nothing if it exists)
INSERT OR IGNORE INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime)
VALUES (105, 101, 1, 11, '2026-11-01', NULL, 'Pending', '10 Nizami St, Baku', '10 Nizami St, Baku', 1, 55, '2026-11-01 10:00:00');
-- Step 3: preview the row that will change
SELECT OrderID, OrderStatus, ShipDate FROM Orders WHERE OrderID = 105;
-- Step 4: update ONLY OrderID 105
UPDATE Orders
SET OrderStatus = 'Shipped',
    ShipDate    = '2026-11-05'
WHERE OrderID = 105;
-- Step 5: verify
SELECT OrderID, OrderStatus, ShipDate FROM Orders WHERE OrderID = 105;

-- [TASK 2.6 | PRACTICE] Address correction for OrderID 110
SELECT * FROM Orders WHERE OrderID = 110;
INSERT OR IGNORE INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime)
VALUES (110, 102, 2, 11, '2026-11-01', NULL, 'Pending', '45 Main St, New York', '45 Main St, New York', 1, 230, '2026-11-01 10:00:00');
SELECT OrderID, ShipAddress FROM Orders WHERE OrderID = 110;  -- before
UPDATE Orders
SET ShipAddress = '45 Main Street, Baku'
WHERE OrderID = 110;
SELECT OrderID, ShipAddress FROM Orders WHERE OrderID = 110;  -- after

-- [TASK 2.7 | PRACTICE] Remove test data (OrderID 999)
SELECT * FROM Orders WHERE OrderID = 999;
INSERT OR IGNORE INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime)
VALUES (999, 104, 9, 15, '2026-11-01', NULL, 'Pending', 'TEST ADDRESS', 'TEST ADDRESS', 1, 12, '2026-11-01 10:00:00');
SELECT * FROM Orders WHERE OrderID = 999;                      -- preview: exactly one row
DELETE FROM Orders
WHERE OrderID = 999;                                           -- only this row
SELECT COUNT(*) AS Row999AfterDelete FROM Orders WHERE OrderID = 999;  -- expect 0

-- [TASK 2.8] Status distribution (reference copy)
SELECT OrderStatus, COUNT(OrderID) AS OrderCount
FROM Orders
GROUP BY OrderStatus
ORDER BY OrderCount DESC, OrderStatus;

-- [TASK 2.9] Unshipped records (reference copy)
-- IS NULL (not "= NULL") tests for missing values. OrderStatus is kept so
-- Pending work, Cancelled orders and inconsistent rows (e.g. Shipped but no
-- ShipDate) can be told apart.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       o.ShipDate,
       o.OrderStatus
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
WHERE o.ShipDate IS NULL
ORDER BY o.OrderDate, o.OrderID;

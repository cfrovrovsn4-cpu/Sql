-- ============================================================================
-- SCENARIO 6 — Sales team review and retention (tasks 6.1–6.10)
-- All read-only -> run on SalesDB.sqlite (clean reference copy)
--
-- QUALIFYING SALE (CTE "qs"): Shipped/Delivered, ShipDate NOT NULL,
-- ShipDate >= OrderDate. The period is assigned by OrderDate:
--   October           2026-10-01 .. 2026-10-31
--   November snapshot 2026-11-01 .. 2026-11-07
-- For the employee tasks (6.2–6.6) the October filter is part of the JOIN
-- condition (ON), so employees without qualifying sales are NOT lost.
-- ============================================================================

-- [TASK 6.1] Reporting lines (self join)
-- Employees is joined to itself: e = the employee, m = the manager.
-- LEFT JOIN keeps Maya Brown (ManagerID IS NULL).
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department,
       e.ManagerID,
       m.FirstName || ' ' || m.LastName AS ManagerName
FROM Employees AS e
LEFT JOIN Employees AS m ON m.EmployeeID = e.ManagerID
ORDER BY e.EmployeeID;

-- [TASK 6.2] October scorecard (all Sales employees, zeros kept)
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(qs.OrderID)           AS OrderCount,
       COALESCE(SUM(qs.Quantity), 0) AS TotalQuantity,
       COALESCE(SUM(qs.Sales), 0)    AS TotalSales
FROM Employees AS e
LEFT JOIN qs ON qs.SalesPersonID = e.EmployeeID
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
ORDER BY TotalSales DESC, e.EmployeeID;

-- [TASK 6.3] Direct-report team summary
-- m = manager, e = DIRECT reports in Sales (e.ManagerID = m.EmployeeID).
-- Orders are joined only for e, so the manager's own sales and indirect reports
-- are excluded. COUNT(DISTINCT e.EmployeeID) counts each employee once even
-- though joining orders repeats the employee on several rows.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT m.EmployeeID AS ManagerID,
       m.FirstName || ' ' || m.LastName AS ManagerName,
       COUNT(DISTINCT e.EmployeeID)   AS DirectSalesStaffCount,
       COUNT(qs.OrderID)              AS TeamOrderCount,
       COALESCE(SUM(qs.Sales), 0)     AS TeamSales
FROM Employees AS m
INNER JOIN Employees AS e
        ON  e.ManagerID  = m.EmployeeID
        AND e.Department = 'Sales'
LEFT JOIN qs ON qs.SalesPersonID = e.EmployeeID
GROUP BY m.EmployeeID, m.FirstName, m.LastName
ORDER BY m.EmployeeID;

-- [TASK 6.4] Staff meeting the monthly target
-- WHERE/ON = row rules (status, dates) BEFORE grouping.
-- HAVING   = target rules (>= 2 orders AND >= 1000) AFTER grouping.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(qs.OrderID) AS OrderCount,
       SUM(qs.Sales)     AS TotalSales
FROM Employees AS e
INNER JOIN qs ON qs.SalesPersonID = e.EmployeeID
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
HAVING COUNT(qs.OrderID) >= 2
   AND SUM(qs.Sales) >= 1000
ORDER BY TotalSales DESC, e.EmployeeID;

-- [TASK 6.5] Customer and country coverage
-- COUNT(DISTINCT ...) so repeat orders for the same customer/country add nothing.
-- LEFT JOINs keep employees with no activity (their distinct counts are 0).
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       COUNT(DISTINCT qs.CustomerID) AS DistinctCustomers,
       COUNT(DISTINCT c.Country)     AS DistinctCountries
FROM Employees AS e
LEFT JOIN qs        ON qs.SalesPersonID = e.EmployeeID
LEFT JOIN Customers AS c ON c.CustomerID = qs.CustomerID
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
ORDER BY e.EmployeeID;

-- [TASK 6.6] Staff without qualifying October sales
-- LEFT JOIN + "qs.OrderID IS NULL" finds Sales employees with no matching row.
-- Someone who has only non-qualifying orders still appears here.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department
FROM Employees AS e
LEFT JOIN qs ON qs.SalesPersonID = e.EmployeeID
WHERE e.Department = 'Sales'
  AND qs.OrderID IS NULL
ORDER BY e.EmployeeID;

-- [TASK 6.7] Returning customers (INTERSECT)
-- Customers with a qualifying sale in October AND in the November snapshot.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
INTERSECT
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
ORDER BY CustomerID;

-- [TASK 6.8] Customers with no return by 2026-11-07 (EXCEPT)
-- October customers MINUS November-snapshot customers. This means "no
-- qualifying return by 2026-11-07", not permanent inactivity.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
EXCEPT
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
ORDER BY CustomerID;

-- [TASK 6.9] Customers new to the comparison period (reverse EXCEPT)
-- November-snapshot customers with no qualifying October sale. This does NOT
-- prove they are first-time buyers: older history is not in this database.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
EXCEPT
SELECT CustomerID FROM qs WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
ORDER BY CustomerID;

-- [TASK 6.10] Two-period sales register (UNION ALL)
-- UNION ALL keeps every row (no duplicate removal). The date ranges do not
-- overlap, so each order lands in exactly one part.
WITH qs AS (
    SELECT * FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
)
SELECT 'October 2026' AS PeriodLabel,
       qs.OrderID, qs.OrderDate, c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = qs.SalesPersonID
WHERE qs.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
UNION ALL
SELECT 'November 01–07' AS PeriodLabel,
       qs.OrderID, qs.OrderDate, c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       qs.Sales
FROM qs
INNER JOIN Customers AS c ON c.CustomerID = qs.CustomerID
INNER JOIN Employees AS e ON e.EmployeeID = qs.SalesPersonID
WHERE qs.OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
ORDER BY OrderDate, OrderID;

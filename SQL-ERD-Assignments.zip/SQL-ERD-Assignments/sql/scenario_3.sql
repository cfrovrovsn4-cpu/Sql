-- ============================================================================
-- SCENARIO 3 — Products and employee performance (tasks 3.1–3.12)
-- Read-only tasks -> run on SalesDB.sqlite (reference copy)
-- 3.8, 3.9, 3.10 -> run ONLY on SalesDB_Practice.sqlite
-- ============================================================================

-- [TASK 3.1] Affordable products
SELECT Product, Category, Price
FROM Products
WHERE Price BETWEEN 50 AND 300
ORDER BY Price ASC;

-- [TASK 3.2] Premium electronics
SELECT ProductID, Product, Category, Price
FROM Products
WHERE Category = 'Electronics'
  AND Price > 500;

-- [TASK 3.3] Product sales
-- One row per order, joined to its product through ProductID.
SELECT p.Product, p.Category, o.Quantity, o.Sales
FROM Products AS p
INNER JOIN Orders AS o ON o.ProductID = p.ProductID
ORDER BY o.OrderID;

-- [TASK 3.4] Best-selling products (top five by total Quantity)
-- Grouped by ProductID; ties are broken by ProductID ascending.
SELECT p.ProductID, p.Product, SUM(o.Quantity) AS TotalQuantity
FROM Products AS p
INNER JOIN Orders AS o ON o.ProductID = p.ProductID
GROUP BY p.ProductID, p.Product
ORDER BY TotalQuantity DESC, p.ProductID
LIMIT 5;

-- [TASK 3.5] Unsold items
-- LEFT JOIN keeps all products; no matching order -> o.OrderID IS NULL.
SELECT p.ProductID, p.Product, p.Category, p.Price
FROM Products AS p
LEFT JOIN Orders AS o ON o.ProductID = p.ProductID
WHERE o.OrderID IS NULL
ORDER BY p.ProductID;

-- [TASK 3.6] Employee performance
-- Employees.EmployeeID = Orders.SalesPersonID. INNER JOIN, so an employee with
-- no orders (EmployeeID 13) does not appear.
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department,
       SUM(o.Sales) AS TotalSales
FROM Employees AS e
INNER JOIN Orders AS o ON o.SalesPersonID = e.EmployeeID
GROUP BY e.EmployeeID, e.FirstName, e.LastName, e.Department
ORDER BY TotalSales DESC, e.EmployeeID;

-- [TASK 3.7] Top-performing staff (total Sales above 5,000)
SELECT e.EmployeeID,
       e.FirstName || ' ' || e.LastName AS EmployeeName,
       e.Department,
       SUM(o.Sales) AS TotalSales
FROM Employees AS e
INNER JOIN Orders AS o ON o.SalesPersonID = e.EmployeeID
GROUP BY e.EmployeeID, e.FirstName, e.LastName, e.Department
HAVING SUM(o.Sales) > 5000
ORDER BY TotalSales DESC;

-- ---------------------------------------------------------------------------
-- 3.8–3.10: PRACTICE COPY ONLY (ProductID 501 is intentionally absent from
-- the reference data).
-- ---------------------------------------------------------------------------

-- [TASK 3.8 | PRACTICE] New product
SELECT * FROM Products WHERE ProductID = 501;    -- expect no row
INSERT INTO Products (ProductID, Product, Category, Price)
VALUES (501, 'Wireless Keyboard', 'Electronics', 75);
SELECT * FROM Products WHERE ProductID = 501;    -- verify

-- [TASK 3.9 | PRACTICE] Price correction
SELECT ProductID, Price FROM Products WHERE ProductID = 501;  -- before: 75
UPDATE Products
SET Price = 90
WHERE ProductID = 501;
SELECT ProductID, Price FROM Products WHERE ProductID = 501;  -- after: 90

-- [TASK 3.10 | PRACTICE] Inventory column
-- ALTER TABLE ... ADD COLUMN is supported by SQLite. Existing rows get NULL.
ALTER TABLE Products ADD COLUMN StockQuantity INTEGER;
SELECT ProductID, Product, Price, StockQuantity FROM Products ORDER BY ProductID;

-- [TASK 3.11] Combined directory
-- UNION removes duplicate (FirstName, LastName) pairs. It lists name
-- combinations only; it does not prove two rows are the same person.
SELECT FirstName, LastName FROM Customers
UNION
SELECT FirstName, LastName FROM Employees
ORDER BY LastName, FirstName;

-- [TASK 3.12] Category performance
-- HAVING keeps only categories whose grouped total exceeds 2,000.
SELECT p.Category,
       SUM(o.Quantity) AS TotalQuantity,
       SUM(o.Sales)    AS TotalSales
FROM Products AS p
INNER JOIN Orders AS o ON o.ProductID = p.ProductID
GROUP BY p.Category
HAVING SUM(o.Sales) > 2000
ORDER BY TotalSales DESC;

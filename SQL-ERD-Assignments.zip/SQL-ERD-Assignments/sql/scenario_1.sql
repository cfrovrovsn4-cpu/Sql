-- ============================================================================
-- SCENARIO 1 — Customer loyalty and sales analysis (tasks 1.1–1.7)
-- All read-only -> run on SalesDB.sqlite (reference copy)
-- Rules: no status/date filter unless a task gives one; Sales is summed as stored.
-- ============================================================================

-- [TASK 1.1] High-score customers
-- Score strictly greater than 500, highest score first.
SELECT FirstName, LastName, Country, Score
FROM Customers
WHERE Score > 500
ORDER BY Score DESC;

-- [TASK 1.2] Target countries
-- IN() is a short form of several OR conditions; Score >= 300 is inclusive.
SELECT FirstName, LastName, Country, Score
FROM Customers
WHERE Country IN ('Germany', 'France', 'USA')
  AND Score >= 300
ORDER BY CustomerID;

-- [TASK 1.3] Purchase history
-- INNER JOIN on CustomerID: only orders that have a matching customer.
SELECT o.OrderID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       o.OrderDate,
       o.Sales
FROM Orders AS o
INNER JOIN Customers AS c ON c.CustomerID = o.CustomerID
ORDER BY o.OrderID;

-- [TASK 1.4] Inactive customers
-- LEFT JOIN keeps every customer; customers with no order get NULL in o.OrderID.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country
FROM Customers AS c
LEFT JOIN Orders AS o ON o.CustomerID = c.CustomerID
WHERE o.OrderID IS NULL
ORDER BY c.CustomerID;

-- [TASK 1.5] Total customer spending
-- Grouped by CustomerID (not by name) so two customers with the same name stay separate.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName, c.Country
ORDER BY TotalSales DESC, c.CustomerID;

-- [TASK 1.6] Loyalty threshold
-- HAVING filters AFTER grouping (WHERE cannot filter on SUM()).
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName, c.Country
HAVING SUM(o.Sales) > 1000
ORDER BY TotalSales DESC, c.CustomerID;

-- [TASK 1.7] Top-five report
-- Same totals, limited to five rows. Ties are broken by CustomerID ascending.
SELECT c.CustomerID,
       c.FirstName || ' ' || c.LastName AS CustomerName,
       c.Country,
       SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName, c.Country
ORDER BY TotalSales DESC, c.CustomerID
LIMIT 5;

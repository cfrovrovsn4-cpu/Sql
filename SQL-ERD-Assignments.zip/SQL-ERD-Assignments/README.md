# SQL & Relational Database Design — SalesDB and ERD Projects

Student solution for the *SQL & Relational Database Design — Student Assignment Pack (Expanded Edition)*.

## Purpose
Build the SalesDB sales database in SQLite, solve 10 basic SQL tasks and 6 business scenarios (58 tasks), and design two ER diagrams (Sales Management and University Course Registration).

- **Database system:** SQLite 3 (built and tested with SQLite 3.53.1)
- **Software:** DB Browser for SQLite (the `.sqlite` files are standard SQLite files)

## Repository structure

```
README.md
database/
  SalesDB.sqlite             clean reference database (never modified)
  SalesDB_Practice.sqlite    practice copy after the modification exercises
sql/
  assignments.sql            ONE complete submission file (setup + all 68 tasks)
  database_setup.sql         CREATE TABLE + 46 reference rows
  basic_tasks.sql           B01–B10
  scenario_1.sql … scenario_6.sql
erd/
  ERD_Project_A.png          Sales Management ERD
  ERD_Project_B.png          University Course Registration ERD
  source/                    Graphviz sources used to draw the diagrams
results/
  basic/, scenario_1/ … scenario_6/
    results_<group>.md       every query with its result table
    explanations_<group>.md  required explanations
    *.csv                    one CSV per result set
tools/                       optional helper scripts (rebuild results / ERDs / assignments.sql)
```

## Database structure
Four tables with the instructor's exact names and columns: `Customers` (9 rows), `Products` (8), `Employees` (5), `Orders` (24) — 46 rows in total.
Foreign keys: `Orders.CustomerID → Customers`, `Orders.ProductID → Products`, `Orders.SalesPersonID → Employees`, `Employees.ManagerID → Employees` (self-reference, nullable). No extra tables, no `OrderItems` table.

## Included SQL tasks

| Part | Tasks | Count |
|---|---|---|
| Basic SQL | B01–B10 | 10 |
| Scenario 1 — Customer loyalty and sales analysis | 1.1–1.7 | 7 |
| Scenario 2 — Order and delivery investigation | 2.1–2.9 | 9 |
| Scenario 3 — Products and employee performance | 3.1–3.12 | 12 |
| Scenario 4 — Targeted campaign planning | 4.1–4.10 | 10 |
| Scenario 5 — Fulfilment exception desk (snapshot 2026-11-07) | 5.1–5.10 | 10 |
| Scenario 6 — Sales team review and retention | 6.1–6.10 | 10 |

Every task is numbered exactly as in the PDF and has a short comment.

## ERD projects
- `erd/ERD_Project_A.png` — Customers, Products, Employees, Orders with all attributes and data types, PK/FK labels, crow's-foot cardinality and optionality, the employee–manager self-reference and relationship explanations.
- `erd/ERD_Project_B.png` — Students, Instructors, Courses, Enrollments with all columns/types, keys, cardinalities, the Student–Course many-to-many explanation, how Enrollments resolves it, and how duplicate registration is prevented (composite `UNIQUE (StudentID, CourseID)`).

## How to open the database
1. Install DB Browser for SQLite.
2. *File → Open Database…* and choose `database/SalesDB.sqlite`.
3. Use *Browse Data* to see the tables and *Database Structure* to see columns and keys.

## How to run the SQL
- **Everything at once:** open an empty database (*File → New Database*), go to *Execute SQL*, open `sql/assignments.sql` and press *Execute all*. It creates the tables, loads the data, runs all read-only tasks and finally runs the modification tasks inside a savepoint that is rolled back, so the data stays clean. (DB Browser shows only the result of the last statement; to see an individual result, select that query and use *Execute current line*/selection.)
- **Task by task:** run `sql/database_setup.sql` once, then any `basic_tasks.sql` / `scenario_N.sql` file.
- **Modification tasks** (B10, 2.5–2.7, 3.8–3.10) are marked `| PRACTICE`; run them only on a copy (`SalesDB_Practice.sqlite`). Re-running `database_setup.sql` restores the reference data.

Foreign keys are enforced with `PRAGMA foreign_keys = ON;` (in DB Browser this is also on by default).

## How to inspect the results
Open `results/<group>/results_<group>.md` (query + table for every task) and `explanations_<group>.md` (required explanations). The CSV files hold the same result sets.

## Implementation notes and assumptions
- SQLite has no `DATEDIFF`; day differences use `julianday(a) - julianday(b)`; `date('2026-11-07','-7 days')` gives the 7-day cut-off in Task 5.2.
- Dates are stored as ISO text (`YYYY-MM-DD`), so comparisons and `BETWEEN` work correctly. `CreationTime` = `OrderDate` + `10:00:00`.
- `Sales` is the total of an order and is never multiplied by `Quantity`.
- In SQLite a compound query (`UNION`/`INTERSECT`/`EXCEPT`) may only `ORDER BY` result-column names, so the Scenario 4 set queries alias `c.CustomerID AS CustomerID`.
- Two intentionally inconsistent records are loaded unchanged: order 221 (Shipped, no ShipDate) and order 222 (ShipDate earlier than OrderDate). They are detected in Task 5.5 and excluded from the qualifying-sale reports (Scenarios 4 and 6).
- No `CHECK`/`NOT NULL` constraints were added beyond keys, so that the audit records (and the NULL addresses/dates) can be stored as the assignment requires.
- Orders 105, 110, 999 and ProductID 501/900 exist only in the practice copy.
- Tasks 2.8 and 2.9 were run on the reference copy so temporary practice rows do not change the counts.

## Verification actually performed
- Table counts (9 / 8 / 5 / 24 = 46), `PRAGMA foreign_key_check` (no violations) and `PRAGMA integrity_check` (ok) on both databases.
- Every loaded value was compared automatically with the text of the PDF: 0 mismatches.
- All 68 numbered tasks were executed in SQLite without errors; `assignments.sql` was executed on an empty database and left data identical to the reference.
- Results of Scenarios 4, 5 and 6 were recomputed independently in Python and match. The remaining scenarios were reviewed by hand against the data.
- Not performed: opening the files in the DB Browser for SQLite GUI (not available in the build environment); they are plain SQLite 3 files.

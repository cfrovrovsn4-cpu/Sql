#!/usr/bin/env python3
"""Builds sql/assignments.sql (the single submission file) from the per-topic SQL files."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HDR = re.compile(r"^-- \[TASK ([^\] |]+)\s*(\| PRACTICE)?\]")
FILES = ["basic_tasks.sql", "scenario_1.sql", "scenario_2.sql", "scenario_3.sql",
         "scenario_4.sql", "scenario_5.sql", "scenario_6.sql"]

readonly, practice = [], []
for f in FILES:
    cur = None
    for line in (ROOT / "sql" / f).read_text(encoding="utf-8").splitlines():
        m = HDR.match(line)
        if m:
            cur = []
            (practice if m.group(2) else readonly).append(cur)
        if cur is not None:
            cur.append(line)

def join(blocks):
    return "\n".join("\n".join(b).rstrip() + "\n" for b in blocks)

setup = (ROOT / "sql" / "database_setup.sql").read_text(encoding="utf-8").rstrip()
out = f"""-- ============================================================================
-- SQL & RELATIONAL DATABASE DESIGN — SalesDB — COMPLETE SUBMISSION FILE
-- DBMS used: SQLite 3 (DB Browser for SQLite)
--
-- PART 1  Database setup (CREATE TABLE + 46 reference rows)
-- PART 2  Read-only tasks, in numeric order (run on the clean reference data):
--         B01–B09, 1.1–1.7, 2.1–2.4, 2.8–2.9, 3.1–3.7, 3.11–3.12,
--         4.1–4.10, 5.1–5.10, 6.1–6.10
-- PART 3  Modification exercises (B10, 2.5–2.7, 3.8–3.10). These change data
--         (INSERT/UPDATE/DELETE/ALTER). They are wrapped in a SAVEPOINT that is
--         rolled back at the end, so this file never leaves changes in the
--         reference database. The permanent practice copy is
--         database/SalesDB_Practice.sqlite (same statements, committed).
-- Task numbers match the assignment. Separate topic files are in sql/.
-- ============================================================================

-- ############################################################################
-- PART 1 — DATABASE SETUP
-- ############################################################################
{setup}

-- ############################################################################
-- PART 2 — READ-ONLY TASKS (reference data)
-- ############################################################################

{join(readonly)}
-- ############################################################################
-- PART 3 — MODIFICATION EXERCISES (practice only; rolled back at the end)
-- ############################################################################
SAVEPOINT practice_exercises;

{join(practice)}
-- Undo everything from PART 3 so the reference data stays clean
ROLLBACK TO practice_exercises;
RELEASE practice_exercises;

-- Final check: reference data must be unchanged (expect 9, 8, 5, 24)
SELECT (SELECT COUNT(*) FROM Customers) AS Customers,
       (SELECT COUNT(*) FROM Products)  AS Products,
       (SELECT COUNT(*) FROM Employees) AS Employees,
       (SELECT COUNT(*) FROM Orders)    AS Orders;
"""
(ROOT / "sql" / "assignments.sql").write_text(out, encoding="utf-8")
print("written", len(out.splitlines()), "lines;", len(readonly), "read-only blocks,", len(practice), "practice blocks")

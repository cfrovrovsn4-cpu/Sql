#!/usr/bin/env python3
"""
Optional helper (not required for the assignment).

Rebuilds the databases and re-runs every numbered task from the sql/ files:
  * database/SalesDB.sqlite          <- sql/database_setup.sql (clean reference copy)
  * database/SalesDB_Practice.sqlite <- copy of the reference + the PRACTICE tasks
  * results/<group>/results_<group>.md and one CSV file per result set

Read-only tasks run on the reference copy; tasks marked "| PRACTICE" run on the
practice copy. Usage (from the repository root):  python3 tools/generate_results.py
"""
import csv
import re
import shutil
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REF = ROOT / "database" / "SalesDB.sqlite"
PRA = ROOT / "database" / "SalesDB_Practice.sqlite"

FILES = ["basic_tasks.sql", "scenario_1.sql", "scenario_2.sql", "scenario_3.sql",
         "scenario_4.sql", "scenario_5.sql", "scenario_6.sql"]
TITLES = {
    "basic": "Basic SQL tasks B01–B10",
    "scenario_1": "Scenario 1 — Customer loyalty and sales analysis",
    "scenario_2": "Scenario 2 — Order and delivery investigation",
    "scenario_3": "Scenario 3 — Products and employee performance",
    "scenario_4": "Scenario 4 — Targeted campaign planning",
    "scenario_5": "Scenario 5 — Fulfilment exception desk",
    "scenario_6": "Scenario 6 — Sales team review and retention",
}
HEADER = re.compile(r"^-- \[TASK ([^\] |]+)\s*(\| PRACTICE)?\]\s*(.*)$")


def group_of(task_id: str) -> str:
    return "basic" if task_id.startswith("B") else "scenario_" + task_id.split(".")[0]


def parse_blocks(path: Path):
    """Return a list of (task_id, practice_flag, title, [statements])."""
    blocks, current, buf = [], None, []
    for line in path.read_text(encoding="utf-8").splitlines():
        m = HEADER.match(line)
        if m:
            current = [m.group(1), bool(m.group(2)), m.group(3).strip(), []]
            blocks.append(current)
            buf = []
            continue
        if current is None:
            continue
        buf.append(line)
        text = "\n".join(buf)
        if sqlite3.complete_statement(text) and text.strip():
            body = "\n".join(l for l in buf if l.strip() and not l.strip().startswith("--"))
            if body.strip():
                current[3].append(text.strip())
            buf = []
    return blocks


def fmt(v):
    if v is None:
        return "NULL"
    if isinstance(v, float):
        return f"{v:.2f}".rstrip("0").rstrip(".") if v != int(v) else str(int(v))
    return str(v)


def md_table(cols, rows):
    if not rows:
        return "_(no rows returned — empty result)_\n"
    out = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for r in rows:
        out.append("| " + " | ".join(fmt(v).replace("|", "\\|") for v in r) + " |")
    return "\n".join(out) + "\n"


def main():
    # 1) clean reference copy
    if REF.exists():
        REF.unlink()
    con = sqlite3.connect(REF)
    con.executescript((ROOT / "sql" / "database_setup.sql").read_text(encoding="utf-8"))
    con.commit()
    con.close()
    # 2) practice copy starts as an exact copy of the reference
    shutil.copyfile(REF, PRA)

    ref = sqlite3.connect(f"file:{REF}?mode=ro", uri=True)
    ref.execute("PRAGMA foreign_keys = ON")
    pra = sqlite3.connect(PRA)
    pra.execute("PRAGMA foreign_keys = ON")

    reports = {g: [] for g in TITLES}
    counts = {"queries": 0, "statements": 0}
    for fname in FILES:
        for task_id, practice, title, stmts in parse_blocks(ROOT / "sql" / fname):
            g = group_of(task_id)
            db = pra if practice else ref
            out_dir = ROOT / "results" / g
            out_dir.mkdir(parents=True, exist_ok=True)
            label = f"Task {task_id}" + (" (practice copy)" if practice else "")
            sec = [f"## {label} — {title}\n"]
            n_sel = 0
            for st in stmts:
                cur = db.execute(st)
                counts["statements"] += 1
                clean = "\n".join(l for l in st.splitlines() if not l.strip().startswith("--")).strip()
                sec.append("```sql\n" + clean + "\n```\n")
                if cur.description is not None:
                    rows = cur.fetchall()
                    cols = [d[0] for d in cur.description]
                    n_sel += 1
                    counts["queries"] += 1
                    safe = task_id.replace(".", "_")
                    suffix = f"_{n_sel}" if len(stmts) > 1 else ""
                    with open(out_dir / f"{safe}{suffix}.csv", "w", newline="", encoding="utf-8") as fh:
                        w = csv.writer(fh)
                        w.writerow(cols)
                        w.writerows([["NULL" if v is None else v for v in r] for r in rows])
                    sec.append(md_table(cols, rows))
                else:
                    sec.append(f"_Statement executed; rows changed: {cur.rowcount}._\n")
            if practice:
                pra.commit()
            reports[g].append("\n".join(sec))

    for g, secs in reports.items():
        text = (f"# {TITLES[g]} — results\n\n"
                "Generated by running the SQL files in SQLite "
                f"{sqlite3.sqlite_version}. Read-only tasks ran on `SalesDB.sqlite`; "
                "tasks marked *practice copy* ran on `SalesDB_Practice.sqlite`. "
                "Empty results are shown as such and were never filled in.\n\n"
                + "\n".join(secs))
        (ROOT / "results" / g / f"results_{g}.md").write_text(text, encoding="utf-8")

    ref.close()
    pra.close()
    print(f"Done: {counts['statements']} statements run, {counts['queries']} result sets saved.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Draws the two ERD projects (original design, crow's-foot notation) with Graphviz,
then adds the title, legend and the short relationship explanations underneath.

Output: erd/ERD_Project_A.png, erd/ERD_Project_B.png (+ Graphviz sources in erd/source/)
Usage (repository root):  python3 tools/make_erd.py
Requires: Graphviz (dot), Pillow, matplotlib (only for its bundled DejaVu fonts)
"""
import subprocess
import textwrap
from pathlib import Path

import matplotlib
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "erd"
SRC = OUT / "source"
SRC.mkdir(parents=True, exist_ok=True)
FONT_DIR = Path(matplotlib.get_data_path()) / "fonts" / "ttf"
F_REG = str(FONT_DIR / "DejaVuSans.ttf")
F_BOLD = str(FONT_DIR / "DejaVuSans-Bold.ttf")

ONE = "teetee"          # exactly one (mandatory)
ZERO_ONE = "teeodot"    # zero or one (optional)
ZERO_MANY = "crowodot"  # zero or many (optional)


def table(name, color, rows):
    """rows: (tag, column, type, note) -> Graphviz HTML-like node label."""
    out = [f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" BGCOLOR="white" COLOR="#334155">',
           f'<TR><TD COLSPAN="3" BGCOLOR="{color}"><FONT POINT-SIZE="20"><B>{name}</B></FONT></TD></TR>']
    for i, (tag, col, typ, note) in enumerate(rows):
        bg = "#f8fafc" if i % 2 else "white"
        tag_html = {"PK": '<B><FONT COLOR="#b45309">PK</FONT></B>',
                    "FK": '<B><FONT COLOR="#1d4ed8">FK</FONT></B>',
                    "PK,FK": '<B><FONT COLOR="#b45309">PK</FONT>,<FONT COLOR="#1d4ed8">FK</FONT></B>',
                    "UK": '<B><FONT COLOR="#047857">UK</FONT></B>',
                    "FK,UK": '<B><FONT COLOR="#1d4ed8">FK</FONT>,<FONT COLOR="#047857">UK</FONT></B>'}.get(tag, "")
        col_html = f"<B><U>{col}</U></B>" if "PK" in tag else (f"<I>{col}</I>" if "FK" in tag else col)
        typ_html = typ + (f' <FONT COLOR="#64748b" POINT-SIZE="13">{note}</FONT>' if note else "")
        out.append(f'<TR><TD BGCOLOR="{bg}" ALIGN="LEFT" WIDTH="46" PORT="{col}_l">{tag_html}</TD>'
                   f'<TD BGCOLOR="{bg}" ALIGN="LEFT">{col_html}</TD>'
                   f'<TD BGCOLOR="{bg}" ALIGN="LEFT" PORT="{col}_r"><FONT COLOR="#475569">{typ_html}</FONT></TD></TR>')
    out.append("</TABLE>>")
    return "".join(out)


def render(dot_text, name):
    dot_file = SRC / f"{name}.dot"
    dot_file.write_text(dot_text, encoding="utf-8")
    png = SRC / f"{name}_diagram.png"
    subprocess.run(["dot", "-Tpng", "-Gdpi=130", str(dot_file), "-o", str(png)], check=True)
    return png


def compose(diagram_png, title, subtitle, sections, out_path):
    """Stack: title bar, diagram, legend, explanation sections."""
    diagram = Image.open(diagram_png).convert("RGB")
    W = max(diagram.width + 120, 2300)
    f_title, f_sub = ImageFont.truetype(F_BOLD, 54), ImageFont.truetype(F_REG, 28)
    f_h, f_t = ImageFont.truetype(F_BOLD, 32), ImageFont.truetype(F_REG, 27)
    f_tb = ImageFont.truetype(F_BOLD, 27)
    wrap_w = int((W - 160) / 14.6)  # characters per line at this font size

    # pre-wrap all text so the canvas height can be calculated
    blocks, y_text = [], 0
    for head, items in sections:
        blocks.append(("h", head))
        y_text += 62
        for lead, body in items:
            lines = textwrap.wrap(lead + body, wrap_w, subsequent_indent="      ")
            blocks.append(("p", lead, lines))
            y_text += 38 * len(lines) + 10
        y_text += 18
    H = 150 + diagram.height + 40 + y_text + 60
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 120], fill="#0f3d4c")
    d.text((60, 22), title, font=f_title, fill="white")
    d.text((62, 128 - 6), "", font=f_sub, fill="white")
    img.paste(diagram, ((W - diagram.width) // 2, 140))
    y = 140 + diagram.height + 30
    d.line([60, y, W - 60, y], fill="#cbd5e1", width=3)
    y += 24
    d.text((60, y - 8), subtitle, font=f_sub, fill="#475569")
    y += 50
    for b in blocks:
        if b[0] == "h":
            d.text((60, y), b[1], font=f_h, fill="#0f3d4c")
            y += 62
        else:
            _, lead, lines = b
            for i, line in enumerate(lines):
                if i == 0:
                    d.text((80, y), lead, font=f_tb, fill="#111827")
                    lw = d.textlength(lead, font=f_tb)
                    d.text((80 + lw, y), line[len(lead):], font=f_t, fill="#1f2937")
                else:
                    d.text((80, y), line, font=f_t, fill="#1f2937")
                y += 38
            y += 10
    img = img.crop((0, 0, W, min(H, y + 40)))
    img.save(out_path)
    print("saved", out_path.relative_to(ROOT), img.size)


GRAPH_HEAD = """digraph G {
  rankdir=LR; splines=true; nodesep=0.9; ranksep=2.8; pad=0.4; bgcolor="white";
  node [shape=plain, fontname="DejaVu Sans", fontsize=16];
  edge [fontname="DejaVu Sans", fontsize=17, color="#334155", penwidth=2.0,
        dir=both, arrowsize=1.4, labelfontsize=17, labeldistance=3.2, labelangle=0];
"""

# ------------------------------------------------------------------ Project A
def project_a():
    dot = GRAPH_HEAD
    dot += f'  Customers [label={table("Customers", "#bfdbfe", [("PK","CustomerID","INTEGER",""),("","FirstName","VARCHAR(50)",""),("","LastName","VARCHAR(50)",""),("","Country","VARCHAR(50)",""),("","Score","INTEGER","")])}];\n'
    dot += f'  Products [label={table("Products", "#fde68a", [("PK","ProductID","INTEGER",""),("","Product","VARCHAR(100)",""),("","Category","VARCHAR(50)",""),("","Price","DECIMAL(10,2)","")])}];\n'
    dot += f'  Orders [label={table("Orders", "#bbf7d0", [("PK","OrderID","INTEGER",""),("FK","ProductID","INTEGER",""),("FK","CustomerID","INTEGER",""),("FK","SalesPersonID","INTEGER",""),("","OrderDate","DATE",""),("","ShipDate","DATE","nullable"),("","OrderStatus","VARCHAR(30)",""),("","ShipAddress","VARCHAR(150)","nullable"),("","BillAddress","VARCHAR(150)","nullable"),("","Quantity","INTEGER",""),("","Sales","DECIMAL(10,2)",""),("","CreationTime","DATETIME","")])}];\n'
    dot += f'  Employees [label={table("Employees", "#e9d5ff", [("PK","EmployeeID","INTEGER",""),("","FirstName","VARCHAR(50)",""),("","LastName","VARCHAR(50)",""),("","Department","VARCHAR(50)",""),("","BirthDate","DATE",""),("","Gender","VARCHAR(10)",""),("","Salary","DECIMAL(10,2)",""),("FK","ManagerID","INTEGER","nullable")])}];\n'
    # tail = parent (one) side, head = Orders (many) side
    dot += f'  Customers:CustomerID_r:e -> Orders:CustomerID_l:w [arrowtail={ONE}, arrowhead={ZERO_MANY}, taillabel="1", headlabel="0..N", label="  places  "];\n'
    dot += f'  Products:ProductID_r:e -> Orders:ProductID_l:w [arrowtail={ONE}, arrowhead={ZERO_MANY}, taillabel="1", headlabel="0..N", label="  appears in  "];\n'
    # tail = Orders (many) side, head = Employees (one) side
    dot += f'  Orders:SalesPersonID_r:e -> Employees:EmployeeID_l:w [arrowtail={ZERO_MANY}, arrowhead={ONE}, taillabel="0..N", headlabel="1", label="  handled by  "];\n'
    # self reference: tail = FK (many), head = PK (manager, zero or one)
    dot += f'  Employees:ManagerID_r:e -> Employees:EmployeeID_r:e [arrowtail={ZERO_MANY}, arrowhead={ZERO_ONE}, taillabel="0..N", headlabel="0..1", label="  reports to  ", constraint=false];\n'
    dot += "}\n"
    png = render(dot, "ERD_Project_A")
    sections = [
        ("Keys", [
            ("Primary keys: ", "Customers.CustomerID, Products.ProductID, Employees.EmployeeID, Orders.OrderID."),
            ("Foreign keys: ", "Orders.CustomerID -> Customers.CustomerID;  Orders.ProductID -> Products.ProductID;  "
                               "Orders.SalesPersonID -> Employees.EmployeeID;  Employees.ManagerID -> Employees.EmployeeID (self-reference).")]),
        ("Relationships (cardinality / optionality)", [
            ("1. Customers 1 : 0..N Orders - ", "A customer may place many orders, or none yet (a registered customer without purchases is allowed, "
             "so the many side is optional). Every order belongs to exactly one customer (mandatory on the Orders side). Link: Orders.CustomerID."),
            ("2. Products 1 : 0..N Orders - ", "A product may appear in many order records, or in none (a product that has never been sold). "
             "Each order record refers to exactly one product, because this simplified model has no OrderItems table. Link: Orders.ProductID."),
            ("3. Employees 1 : 0..N Orders - ", "A sales employee may handle many orders, or none (for example a support employee). "
             "Each order is assigned to exactly one employee. Link: Orders.SalesPersonID -> Employees.EmployeeID."),
            ("4. Employees (manager) 0..1 : 0..N Employees (reports to) - ", "Recursive relationship inside Employees. An employee has at most one manager, "
             "and ManagerID is NULL for the top manager (optional). A manager may supervise several employees, or none. Link: Employees.ManagerID -> Employees.EmployeeID.")]),
    ]
    compose(png, "ERD Project A - Sales Management Database (SalesDB)",
            "Notation: crow's foot.  | = exactly one (mandatory)   o| = zero or one (optional)   o< = zero or many (optional)   PK = primary key   FK = foreign key",
            sections, OUT / "ERD_Project_A.png")


# ------------------------------------------------------------------ Project B
def project_b():
    dot = GRAPH_HEAD.replace("ranksep=2.8", "ranksep=2.8")
    dot += f'  Students [label={table("Students", "#bfdbfe", [("PK","StudentID","INT",""),("","FirstName","VARCHAR(50)",""),("","LastName","VARCHAR(50)",""),("","Email","VARCHAR(100)",""),("","BirthDate","DATE",""),("","Faculty","VARCHAR(100)",""),("","EnrollmentYear","INT","")])}];\n'
    dot += f'  Instructors [label={table("Instructors", "#e9d5ff", [("PK","InstructorID","INT",""),("","FirstName","VARCHAR(50)",""),("","LastName","VARCHAR(50)",""),("","Department","VARCHAR(100)",""),("","Email","VARCHAR(100)",""),("","Salary","DECIMAL(10,2)","")])}];\n'
    dot += f'  Courses [label={table("Courses", "#fde68a", [("PK","CourseID","INT",""),("","CourseName","VARCHAR(100)",""),("","Credits","INT",""),("","Semester","VARCHAR(20)",""),("FK","InstructorID","INT","")])}];\n'
    dot += f'  Enrollments [label={table("Enrollments", "#bbf7d0", [("PK","EnrollmentID","INT",""),("FK,UK","StudentID","INT",""),("FK,UK","CourseID","INT",""),("","EnrollmentDate","DATE",""),("","Grade","DECIMAL(5,2)",""),("","Status","VARCHAR(20)","")])}];\n'
    dot += f'  Students:StudentID_r:e -> Enrollments:StudentID_l:w [arrowtail={ONE}, arrowhead={ZERO_MANY}, taillabel="1", headlabel="0..N", label="  registers  "];\n'
    dot += f'  Courses:CourseID_r:e -> Enrollments:CourseID_l:w [arrowtail={ONE}, arrowhead={ZERO_MANY}, taillabel="1", headlabel="0..N", label="  is registered in  "];\n'
    dot += f'  Instructors:InstructorID_r:e -> Courses:InstructorID_l:w [arrowtail={ONE}, arrowhead={ZERO_MANY}, taillabel="1", headlabel="0..N", label="  teaches  "];\n'
    dot += "}\n"
    png = render(dot, "ERD_Project_B")
    sections = [
        ("Keys", [
            ("Primary keys (B1): ", "Students.StudentID, Instructors.InstructorID, Courses.CourseID, Enrollments.EnrollmentID."),
            ("Foreign keys (B2): ", "Courses.InstructorID -> Instructors.InstructorID;  Enrollments.StudentID -> Students.StudentID;  "
                                    "Enrollments.CourseID -> Courses.CourseID.  UK = part of the composite UNIQUE (StudentID, CourseID).")]),
        ("Relationships (B4, B6)", [
            ("1. Instructors 1 : 0..N Courses - ", "Each course is taught by exactly one instructor; an instructor may teach several courses (or none yet). Link: Courses.InstructorID."),
            ("2. Students 1 : 0..N Enrollments - ", "A student may have many enrollment records (one per course registered); each enrollment belongs to exactly one student. Link: Enrollments.StudentID."),
            ("3. Courses 1 : 0..N Enrollments - ", "A course may have many enrollment records (one per student registered); each enrollment belongs to exactly one course. Link: Enrollments.CourseID.")]),
        ("How Enrollments represents registrations (B5)", [
            ("Many-to-many resolved: ", "Students and Courses are M:N (a student takes several courses and a course has several students). "
             "A relational table cannot store that directly, so the junction table Enrollments turns it into two 1:N relationships: "
             "Students 1:N Enrollments and Courses 1:N Enrollments. One Enrollments row links ONE student to ONE course and also stores "
             "the attributes of that link: EnrollmentDate, Grade and Status.")]),
        ("Preventing duplicate registration (B7)", [
            ("Composite UNIQUE constraint: ", "Enrollments has its own primary key EnrollmentID, and in addition a UNIQUE constraint on the pair "
             "(StudentID, CourseID). The database then rejects a second row with the same student and course, so a student can register for a given "
             "course only once, as business rule 6 requires. Different students or different courses are still allowed.")]),
    ]
    compose(png, "ERD Project B - University Course Registration",
            "Notation: crow's foot.  | = exactly one (mandatory)   o< = zero or many (optional)   PK = primary key   FK = foreign key   UK = unique key (composite)",
            sections, OUT / "ERD_Project_B.png")


if __name__ == "__main__":
    project_a()
    project_b()
